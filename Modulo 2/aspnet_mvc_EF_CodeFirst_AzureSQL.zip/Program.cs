
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllersWithViews();

var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(name:"default",pattern:"{controller=Invoices}/{action=Index}/{id?}");
app.Run();

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<InvoiceProduct> InvoiceProducts => Set<InvoiceProduct>();
}

public class Customer
{
    public int Id {get;set;}
    public string Name {get;set;}="";
}

public class Product
{
    public int Id {get;set;}
    public string Name {get;set;}="";
    public decimal Price {get;set;}
}

public class Invoice
{
    public int Id {get;set;}
    public int CustomerId {get;set;}
    public Customer Customer {get;set;}
    public ICollection<InvoiceProduct> Items {get;set;} = new List<InvoiceProduct>();
}

public class InvoiceProduct
{
    public int InvoiceId {get;set;}
    public Invoice Invoice {get;set;}
    public int ProductId {get;set;}
    public Product Product {get;set;}
}
