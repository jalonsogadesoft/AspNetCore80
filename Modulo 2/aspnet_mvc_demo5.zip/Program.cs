using Microsoft.EntityFrameworkCore;
using aspnet_mvc_demo5.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllersWithViews();

var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(name:"default",pattern:"{controller=Invoices}/{action=Index}/{id?}");

app.Run();