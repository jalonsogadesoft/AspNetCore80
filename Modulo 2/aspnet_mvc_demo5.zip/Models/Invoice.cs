using System.ComponentModel.DataAnnotations;

namespace aspnet_mvc_demo5.Models
{
    public class Invoice
    {
        public int Id { get; set; }

        [Required]
        public string Number { get; set; } = "";

        [Required]
        public string Customer { get; set; } = "";

        [Range(1,10000)]
        public decimal Amount { get; set; }

        public DateTime Date { get; set; }
    }
}