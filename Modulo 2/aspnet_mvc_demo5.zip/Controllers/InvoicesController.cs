using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo5.Data;
using aspnet_mvc_demo5.Models;

namespace aspnet_mvc_demo5.Controllers
{
    public class InvoicesController : Controller
    {
        private readonly AppDbContext _context;

        public InvoicesController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Invoices.ToList());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Invoice model)
        {
            if (!ModelState.IsValid)
                return View(model);

            _context.Invoices.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}