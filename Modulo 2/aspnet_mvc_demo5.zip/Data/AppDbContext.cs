using Microsoft.EntityFrameworkCore;
using aspnet_mvc_demo5.Models;

namespace aspnet_mvc_demo5.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}

        public DbSet<Invoice> Invoices => Set<Invoice>();
    }
}