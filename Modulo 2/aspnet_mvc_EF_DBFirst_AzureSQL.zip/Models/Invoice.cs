
public partial class Invoice
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
}
