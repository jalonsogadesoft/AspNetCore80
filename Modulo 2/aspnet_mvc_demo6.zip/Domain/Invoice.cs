
namespace aspnet_mvc_demo6.Domain;

public class Invoice
{
    public int Id {get;set;}
    public string Number {get;set;}="";
    public string Customer {get;set;}="";
    public decimal Amount {get;set;}
    public DateTime Date {get;set;}
}
