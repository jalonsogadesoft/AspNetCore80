
using Microsoft.EntityFrameworkCore;
using aspnet_mvc_demo6.Infrastructure;
using aspnet_mvc_demo6.Application.Services;
using aspnet_mvc_demo6.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(o=>o.UseSqlite("Data Source=app.db"));
builder.Services.AddScoped<IInvoiceRepository, InvoiceRepository>();
builder.Services.AddScoped<IInvoiceService, InvoiceService>();

builder.Services.AddControllersWithViews();
builder.Services.AddControllers(); // API

var app=builder.Build();
app.UseStaticFiles();
app.UseRouting();

app.MapControllers(); // API
app.MapControllerRoute(name:"default",pattern:"{controller=Invoices}/{action=Index}/{id?}");

app.Run();
