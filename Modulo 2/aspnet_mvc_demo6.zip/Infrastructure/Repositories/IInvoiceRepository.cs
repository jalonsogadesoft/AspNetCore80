
using aspnet_mvc_demo6.Domain;

namespace aspnet_mvc_demo6.Infrastructure.Repositories;

public interface IInvoiceRepository
{
    IQueryable<Invoice> GetAll();
    Invoice? Get(int id);
    void Add(Invoice i);
    void Save();
}
