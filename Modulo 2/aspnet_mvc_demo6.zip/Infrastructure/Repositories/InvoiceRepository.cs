
using aspnet_mvc_demo6.Domain;

namespace aspnet_mvc_demo6.Infrastructure.Repositories;

public class InvoiceRepository:IInvoiceRepository
{
    private readonly AppDbContext _ctx;
    public InvoiceRepository(AppDbContext ctx){_ctx=ctx;}

    public IQueryable<Invoice> GetAll()=>_ctx.Invoices;
    public Invoice? Get(int id)=>_ctx.Invoices.Find(id);
    public void Add(Invoice i)=>_ctx.Invoices.Add(i);
    public void Save()=>_ctx.SaveChanges();
}
