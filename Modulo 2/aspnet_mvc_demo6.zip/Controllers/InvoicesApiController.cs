
using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo6.Application.Services;

namespace aspnet_mvc_demo6.Controllers;

[ApiController]
[Route("api/invoices")]
public class InvoicesApiController:ControllerBase
{
    private readonly IInvoiceService _svc;
    public InvoicesApiController(IInvoiceService svc){_svc=svc;}

    [HttpGet]
    public IActionResult Get()=>Ok(_svc.GetPaged(null));
}
