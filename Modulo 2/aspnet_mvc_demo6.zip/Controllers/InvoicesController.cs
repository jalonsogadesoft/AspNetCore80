
using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo6.Application.Services;
using aspnet_mvc_demo6.Application.ViewModels;
using aspnet_mvc_demo6.Domain;

namespace aspnet_mvc_demo6.Controllers;

public class InvoicesController:Controller
{
    private readonly IInvoiceService _svc;
    public InvoicesController(IInvoiceService svc){_svc=svc;}

    public IActionResult Index(string? search,int page=1)
    {
        var data=_svc.GetPaged(search,page);
        return View(data);
    }

    public IActionResult Create()=>View();

    [HttpPost]
    public IActionResult Create(InvoiceVM vm)
    {
        var entity=new Invoice{
            Number=vm.Number,
            Customer=vm.Customer,
            Amount=vm.Amount,
            Date=vm.Date
        };
        _svc.Create(entity);
        return RedirectToAction("Index");
    }
}
