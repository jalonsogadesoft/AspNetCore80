
using aspnet_mvc_demo6.Domain;
using aspnet_mvc_demo6.Infrastructure.Repositories;

namespace aspnet_mvc_demo6.Application.Services;

public class InvoiceService:IInvoiceService
{
    private readonly IInvoiceRepository _repo;
    public InvoiceService(IInvoiceRepository repo){_repo=repo;}

    public IEnumerable<Invoice> GetPaged(string? search,int page=1,int pageSize=5)
    {
        var q=_repo.GetAll();
        if(!string.IsNullOrEmpty(search))
            q=q.Where(x=>x.Customer.Contains(search));
        return q.Skip((page-1)*pageSize).Take(pageSize).ToList();
    }

    public void Create(Invoice i)
    {
        _repo.Add(i);
        _repo.Save();
    }
}
