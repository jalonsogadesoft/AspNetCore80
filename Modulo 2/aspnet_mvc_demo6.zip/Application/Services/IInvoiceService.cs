
using aspnet_mvc_demo6.Domain;

namespace aspnet_mvc_demo6.Application.Services;

public interface IInvoiceService
{
    IEnumerable<Invoice> GetPaged(string? search,int page=1,int pageSize=5);
    void Create(Invoice invoice);
}
