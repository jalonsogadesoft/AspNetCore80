
namespace aspnet_mvc_demo6.Application.ViewModels;

public class InvoiceVM
{
    public string Number {get;set;}="";
    public string Customer {get;set;}="";
    public decimal Amount {get;set;}
    public DateTime Date {get;set;}
}
