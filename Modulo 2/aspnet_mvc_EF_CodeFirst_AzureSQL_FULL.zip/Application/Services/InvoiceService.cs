
using Domain.Entities;

public class InvoiceService{
 private readonly IRepository<Invoice> _repo;
 public InvoiceService(IRepository<Invoice> repo){_repo=repo;}
 public async Task<List<Invoice>> GetAll()=>await _repo.GetAllAsync();
 public async Task Create(Invoice i){await _repo.AddAsync(i);await _repo.SaveAsync();}
}
