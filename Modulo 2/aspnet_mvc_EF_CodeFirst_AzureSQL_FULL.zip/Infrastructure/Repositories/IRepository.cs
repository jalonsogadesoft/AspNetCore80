
using System.Linq.Expressions;
public interface IRepository<T> where T:class{
 Task<List<T>> GetAllAsync();
 Task<T> GetByIdAsync(int id);
 Task AddAsync(T e);
 void Update(T e);
 void Delete(T e);
 Task SaveAsync();
}
