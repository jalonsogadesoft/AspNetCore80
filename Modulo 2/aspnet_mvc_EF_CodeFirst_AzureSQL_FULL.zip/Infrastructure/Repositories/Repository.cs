
using Microsoft.EntityFrameworkCore;
using Infrastructure;

public class Repository<T>:IRepository<T> where T:class{
 private readonly AppDbContext _ctx;
 private readonly DbSet<T> _db;
 public Repository(AppDbContext ctx){_ctx=ctx;_db=ctx.Set<T>();}
 public async Task<List<T>> GetAllAsync()=>await _db.ToListAsync();
 public async Task<T> GetByIdAsync(int id)=>await _db.FindAsync(id);
 public async Task AddAsync(T e)=>await _db.AddAsync(e);
 public void Update(T e)=>_db.Update(e);
 public void Delete(T e)=>_db.Remove(e);
 public async Task SaveAsync()=>await _ctx.SaveChangesAsync();
}
