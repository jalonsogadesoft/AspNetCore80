
using Microsoft.EntityFrameworkCore;
using Domain.Entities;
namespace Infrastructure;
public class AppDbContext:DbContext{
 public AppDbContext(DbContextOptions<AppDbContext> o):base(o){}
 public DbSet<Customer> Customers=>Set<Customer>();
 public DbSet<Product> Products=>Set<Product>();
 public DbSet<Invoice> Invoices=>Set<Invoice>();
 public DbSet<InvoiceProduct> InvoiceProducts=>Set<InvoiceProduct>();
}
