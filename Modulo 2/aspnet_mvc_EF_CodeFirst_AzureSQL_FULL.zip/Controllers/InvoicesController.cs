
using Microsoft.AspNetCore.Mvc;
using Domain.Entities;

public class InvoicesController:Controller{
 private readonly InvoiceService _svc;
 public InvoicesController(InvoiceService s){_svc=s;}
 public async Task<IActionResult> Index()=>View(await _svc.GetAll());
 public IActionResult Create()=>View();
 [HttpPost]
 public async Task<IActionResult> Create(Invoice i){await _svc.Create(i);return RedirectToAction("Index");}
}
