
using Microsoft.EntityFrameworkCore;

var builder=WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<Infrastructure.AppDbContext>(o=>
 o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddScoped(typeof(IRepository<>),typeof(Repository<>));
builder.Services.AddScoped<InvoiceService>();

builder.Services.AddControllersWithViews();

var app=builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name:"default",pattern:"{controller=Invoices}/{action=Index}/{id?}");
app.Run();
