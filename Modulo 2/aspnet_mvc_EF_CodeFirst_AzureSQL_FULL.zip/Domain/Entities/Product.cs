
namespace Domain.Entities;
public class Product { public int Id{get;set;} public string Name{get;set;}=""; public decimal Price{get;set;} public List<InvoiceProduct> Items{get;set;}=new(); }
