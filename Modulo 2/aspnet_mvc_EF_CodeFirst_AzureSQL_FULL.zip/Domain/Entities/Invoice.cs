
namespace Domain.Entities;
public class Invoice { public int Id{get;set;} public int CustomerId{get;set;} public Customer Customer{get;set;} public List<InvoiceProduct> Items{get;set;}=new(); }
