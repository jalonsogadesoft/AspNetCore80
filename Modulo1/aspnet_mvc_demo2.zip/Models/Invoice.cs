namespace aspnet_mvc_demo2.Models
{
    public class Invoice
    {
        public int Id { get; set; }
        public string Number { get; set; } = string.Empty;
        public string Customer { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
    }
}
