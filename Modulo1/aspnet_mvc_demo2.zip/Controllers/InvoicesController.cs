using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo2.Models;

namespace aspnet_mvc_demo2.Controllers
{
    [Route("invoices")]
    public class InvoicesController : Controller
    {
        private static List<Invoice> _invoices = new List<Invoice>
        {
            new Invoice { Id=1, Number="INV-001", Customer="Microsoft", Date=DateTime.Now.AddDays(-10), Amount=1200 },
            new Invoice { Id=2, Number="INV-002", Customer="Apple", Date=DateTime.Now.AddMonths(-2), Amount=800 },
            new Invoice { Id=3, Number="INV-003", Customer="Google", Date=DateTime.Now.AddDays(-5), Amount=1500 }
        };

        // GET /invoices
        [HttpGet("")]
        public IActionResult Index()
        {
            return View(_invoices);
        }

        // GET /invoices/last-month
        [HttpGet("last-month")]
        public IActionResult LastMonth()
        {
            var lastMonth = DateTime.Now.AddMonths(-1);
            var result = _invoices.Where(i => i.Date >= lastMonth).ToList();
            return View("Index", result);
        }

        // GET /invoices/by-number/INV-001
        [HttpGet("by-number/{number}")]
        public IActionResult ByNumber([FromRoute] string number)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Number == number);
            return View("Details", invoice);
        }

        // GET /invoices/search?number=INV-001
        [HttpGet("search")]
        public IActionResult Search([FromQuery] string number)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Number == number);
            return View("Details", invoice);
        }
    }
}
