# ASP.NET Core 8 - Múltiples Entornos

## Objetivo
Demostrar cómo ASP.NET Core maneja distintos entornos.

## Archivos de configuración

- appsettings.json (base)
- appsettings.Development.json
- appsettings.Production.json

## Ejecutar en Development (default)

dotnet run

## Ejecutar en Production

Windows:
set ASPNETCORE_ENVIRONMENT=Production

dotnet run

Linux/Mac:
export ASPNETCORE_ENVIRONMENT=Production

dotnet run

## Endpoints

- /env      → info del entorno actual
- /mensaje  → comportamiento diferente por entorno

## Conceptos clave

- EnvironmentName
- IsDevelopment / IsProduction
- Configuración por entorno
- Middleware específico por entorno
