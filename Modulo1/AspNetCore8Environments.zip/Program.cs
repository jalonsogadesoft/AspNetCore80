var builder = WebApplication.CreateBuilder(args);

// =====================================
// DEMO DE MÚLTIPLES ENTORNOS
// =====================================
// ASP.NET Core usa automáticamente:
// - appsettings.json
// - appsettings.Development.json
// - appsettings.Production.json

var app = builder.Build();

// Endpoint para ver entorno actual
app.MapGet("/env", (IHostEnvironment env) =>
{
    return Results.Json(new
    {
        Entorno = env.EnvironmentName,
        EsDevelopment = env.IsDevelopment(),
        EsProduction = env.IsProduction()
    });
});

// Endpoint con comportamiento diferente
app.MapGet("/mensaje", (IHostEnvironment env, IConfiguration config) =>
{
    var mensaje = config["App:Mensaje"];

    if (env.IsDevelopment())
    {
        return Results.Text($"[DEV] {mensaje} - Información detallada para desarrollo");
    }

    if (env.IsProduction())
    {
        return Results.Text($"[PROD] {mensaje}");
    }

    return Results.Text($"[OTRO] {mensaje}");
});

// Middleware dependiente del entorno
if (app.Environment.IsDevelopment())
{
    app.Use(async (context, next) =>
    {
        Console.WriteLine("Middleware SOLO en Development");
        await next();
    });
}

app.Run();
