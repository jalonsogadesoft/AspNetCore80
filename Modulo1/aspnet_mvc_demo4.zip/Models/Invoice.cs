using System.ComponentModel.DataAnnotations;
using aspnet_mvc_demo4.Validators;

namespace aspnet_mvc_demo4.Models
{
    public class Invoice
    {
        public int Id {get;set;}

        [Required]
        [StringLength(10,MinimumLength=5)]
        public string Number {get;set;}="";

        [Required]
        public string Customer {get;set;}="";

        [Range(1,10000)]
        public decimal Amount {get;set;}

        [NotFutureDate]
        public DateTime Date {get;set;}

        [EmailAddress]
        public string ContactEmail {get;set;}="";
    }
}