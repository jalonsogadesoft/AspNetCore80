using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo4.Models;

namespace aspnet_mvc_demo4.Controllers
{
    public class InvoicesController:Controller
    {
        static List<Invoice> data=new();

        public IActionResult Index()=>View(data);

        public IActionResult Create()=>View();

        [HttpPost]
        public IActionResult Create(Invoice model)
        {
            if(model.Customer=="Admin")
                ModelState.AddModelError("Customer","Nombre no permitido");

            if(!ModelState.IsValid)
                return View(model);

            model.Id=data.Count+1;
            data.Add(model);
            return RedirectToAction("Index");
        }
    }
}