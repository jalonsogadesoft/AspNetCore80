using System.ComponentModel.DataAnnotations;

namespace aspnet_mvc_demo4.Validators
{
    public class NotFutureDateAttribute:ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if(value is DateTime d)
                return d<=DateTime.Now;
            return true;
        }
    }
}