using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// ==============================
// 1. CONFIGURACIÓN BÁSICA
// ==============================
// appsettings.json ya se carga por defecto
string valorSimple = builder.Configuration["App:Nombre"] ?? "(no definido)";

// ==============================
// 2. BINDING A CLASE (Options Pattern)
// ==============================
builder.Services.Configure<MiConfiguracion>(
    builder.Configuration.GetSection("MiConfiguracion"));

// ==============================
// 3. CONFIGURACIÓN DESDE VARIABLES DE ENTORNO
// ==============================
// Ejemplo: set App__Nombre=NuevoValor
string desdeEnv = builder.Configuration["App:Nombre"];

// ==============================
// 4. CONFIGURACIÓN FUERTE + VALIDACIÓN
// ==============================
builder.Services.AddOptions<MiConfiguracion>()
    .Bind(builder.Configuration.GetSection("MiConfiguracion"))
    .Validate(config => !string.IsNullOrEmpty(config.Mensaje),
        "Mensaje no puede estar vacío");

var app = builder.Build();

// ==============================
// USO DE IOptions
// ==============================
app.MapGet("/options", (IOptions<MiConfiguracion> options) =>
{
    return Results.Json(options.Value);
});

// ==============================
// USO DE IOptionsSnapshot (scoped)
// ==============================
app.MapGet("/snapshot", (IOptionsSnapshot<MiConfiguracion> options) =>
{
    return Results.Json(options.Value);
});

// ==============================
// USO DE IOptionsMonitor (reactivo)
// ==============================
app.MapGet("/monitor", (IOptionsMonitor<MiConfiguracion> options) =>
{
    return Results.Json(options.CurrentValue);
});

// ==============================
// LECTURA DIRECTA
// ==============================
app.MapGet("/raw", (IConfiguration config) =>
{
    return Results.Text(config["MiConfiguracion:Mensaje"] ?? "(null)");
});

// ==============================
// DEMO BÁSICA
// ==============================
app.MapGet("/", () =>
{
    return Results.Text($"Valor simple: {valorSimple}");
});

app.Run();

public class MiConfiguracion
{
    public string? Mensaje { get; set; }
    public int Numero { get; set; }
}
