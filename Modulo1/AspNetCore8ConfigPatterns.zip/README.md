# Patrones de Configuración - ASP.NET Core 8

## Incluye ejemplos de:

1. IConfiguration (acceso directo)
2. Options Pattern (IOptions)
3. IOptionsSnapshot
4. IOptionsMonitor
5. Binding a clases
6. Validación de configuración
7. Variables de entorno

## Ejecutar

dotnet run

## Endpoints

- /           -> valor simple
- /raw        -> IConfiguration
- /options    -> IOptions
- /snapshot   -> IOptionsSnapshot
- /monitor    -> IOptionsMonitor

## Probar variables entorno

Windows:
set App__Nombre=OtroNombre

dotnet run

