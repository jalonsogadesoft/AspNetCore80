using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

[ApiController]
[Route("[controller]")]
public class DemoController : ControllerBase
{
    private readonly IServicioSaludo _servicio;
    private readonly DemoOptions _options;

    public DemoController(IServicioSaludo servicio, IOptions<DemoOptions> options)
    {
        _servicio = servicio;
        _options = options.Value;
    }

    [HttpGet("mensaje")]
    public string GetMensaje()
    {
        return $"Mensaje config: {_options.Mensaje}";
    }

    [HttpGet("saludo")]
    public string GetSaludo()
    {
        return _servicio.Saludar();
    }
}
