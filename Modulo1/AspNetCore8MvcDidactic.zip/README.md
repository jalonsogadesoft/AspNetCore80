# ASP.NET Core 8 - MVC Didáctico

## Incluye
- Controllers (MVC)
- Middleware custom (Use)
- DI (servicio)
- Options Pattern
- Static Files (wwwroot)
- Sin redirección HTTPS (simplificado)

## Ejecutar

dotnet run

## Endpoints

- /Demo/mensaje
- /Demo/saludo

## Archivo estático

http://localhost:5000/index.html
