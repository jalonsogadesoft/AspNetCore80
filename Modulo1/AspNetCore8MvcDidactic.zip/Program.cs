using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// ==============================
// CONFIGURACIÓN (Options Pattern)
// ==============================
builder.Services.Configure<DemoOptions>(
    builder.Configuration.GetSection("DemoOptions"));

// ==============================
// INYECCIÓN DE DEPENDENCIAS
// ==============================
builder.Services.AddSingleton<IServicioSaludo, ServicioSaludo>();

// ==============================
// MVC (Controllers)
// ==============================
builder.Services.AddControllers();

var app = builder.Build();

// ==============================
// PIPELINE MIDDLEWARE
// ==============================

// ⚠ NO usamos redirección HTTPS (para simplificar demo)
// app.UseHttpsRedirection();

// Servir archivos estáticos (wwwroot)
app.UseStaticFiles();

// Middleware personalizado
app.Use(async (context, next) =>
{
    Console.WriteLine("Middleware - Antes");
    await next();
    Console.WriteLine("Middleware - Después");
});

// Routing
app.UseRouting();

// Endpoints
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();

// ==============================
// CLASES
// ==============================
public class DemoOptions
{
    public string? Mensaje { get; set; }
}

public interface IServicioSaludo
{
    string Saludar();
}

public class ServicioSaludo : IServicioSaludo
{
    public string Saludar() => "Hola desde servicio DI";
}
