# ASP.NET Core 8 - Prioridad de Configuración

## Objetivo
Demostrar qué fuente gana cuando hay varias configuraciones.

## Orden de prioridad
1. appsettings.json
2. appsettings.Development.json
3. User Secrets
4. Variables de entorno

## Pasos didácticos

### 1. Ejecutar sin cambios
Resultado esperado:
/config → appsettings o development

### 2. Añadir User Secret

dotnet user-secrets init
dotnet user-secrets set "Demo:Valor" "secret"

Resultado:
/config → secret

### 3. Añadir variable de entorno

Windows:
set Demo__Valor=env

Linux/Mac:
export Demo__Valor=env

Resultado:
/config → env

## Endpoints
- /config  → valor ganador
- /debug   → info adicional
- /options → binding tipado
