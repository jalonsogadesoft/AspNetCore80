using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// ============================================
// DEMO: PRIORIDAD DE CONFIGURACIÓN
// ============================================
// Orden real (de menor a mayor prioridad):
// 1. appsettings.json
// 2. appsettings.Development.json
// 3. User Secrets
// 4. Variables de entorno

// Binding fuertemente tipado
builder.Services.Configure<DemoSettings>(
    builder.Configuration.GetSection("Demo"));

var app = builder.Build();

// Devuelve el valor final (el "ganador")
app.MapGet("/config", (IConfiguration config) =>
{
    return Results.Text($"Valor final: {config["Demo:Valor"]}");
});

// Devuelve todas las fuentes posibles (debug didáctico)
app.MapGet("/debug", (IConfiguration config) =>
{
    var valor = config["Demo:Valor"];
    return Results.Json(new
    {
        ValorFinal = valor,
        Nota = "Comprueba appsettings, secrets y env vars"
    });
});

// Options pattern
app.MapGet("/options", (IOptions<DemoSettings> opt) =>
{
    return Results.Json(opt.Value);
});

app.Run();

public class DemoSettings
{
    public string? Valor { get; set; }
}
