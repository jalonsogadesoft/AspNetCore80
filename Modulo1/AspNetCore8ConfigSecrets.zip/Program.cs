using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// ==============================
// CONFIGURACIÓN BASE
// ==============================
// appsettings.json + appsettings.{Environment}.json + env vars

// ==============================
// USER SECRETS (solo Development)
// ==============================
if (builder.Environment.IsDevelopment())
{
    builder.Configuration.AddUserSecrets<Program>();
}

// ==============================
// CLASE DE CONFIGURACIÓN
// ==============================
builder.Services.Configure<DbSettings>(
    builder.Configuration.GetSection("Database"));

var app = builder.Build();

// ==============================
// ENDPOINT: ver config (sin secreto)
// ==============================
app.MapGet("/db", (IOptions<DbSettings> options) =>
{
    return Results.Json(options.Value);
});

// ==============================
// ENDPOINT: leer secreto directamente
// ==============================
app.MapGet("/secret", (IConfiguration config) =>
{
    var password = config["Database:Password"];
    return Results.Text(password != null ? "Secreto cargado correctamente" : "No hay secreto");
});

app.Run();

public class DbSettings
{
    public string? Server { get; set; }
    public string? Database { get; set; }
    public string? User { get; set; }
    public string? Password { get; set; } // vendrá de secrets
}
