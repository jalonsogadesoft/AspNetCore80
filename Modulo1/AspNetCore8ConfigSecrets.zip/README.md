# ASP.NET Core 8 - Configuración con Secretos

## 🔐 Incluye

- User Secrets (desarrollo)
- Separación de secretos y config
- Binding a objeto (DbSettings)

## ✅ Crear secreto

Ejecutar en carpeta del proyecto:

dotnet user-secrets init

dotnet user-secrets set "Database:Password" "MiPasswordSuperSecreto"

## ▶ Ejecutar

dotnet run

## 🔎 Endpoints

- /db      -> muestra configuración (incluye password si está presente)
- /secret  -> confirma si el secreto está cargado

## 💡 Conceptos

- Los secretos NO van en appsettings.json
- Se almacenan en el equipo local del desarrollador
- Solo se usan en entorno Development

## 🌍 Alternativas reales

- Variables de entorno
- Azure Key Vault
- Secret Manager (Docker / Kubernetes)
