using Microsoft.AspNetCore.Mvc;
using MVCApp.Models;

namespace MVCApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var model = new GreetingModel { Message = "Hola desde el patrón MVC" };
            return View(model);
        }
    }
}
