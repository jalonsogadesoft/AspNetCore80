namespace MVCApp.Models
{
    public class GreetingModel
    {
        public string Message { get; set; }
    }
}
