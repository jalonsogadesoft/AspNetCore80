using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo3.Models;

namespace aspnet_mvc_demo3.Controllers
{
    public class InvoicesController : Controller
    {
        private static List<Invoice> _invoices = new List<Invoice>
        {
            new Invoice { Id=1, Number="INV-001", Customer="Microsoft", Date=DateTime.Now.AddDays(-5), Amount=1200 }
        };

        public IActionResult Index() => View(_invoices);

        public IActionResult Details(int id)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Id == id);
            return View(invoice);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Invoice invoice)
        {
            invoice.Id = _invoices.Max(i => i.Id) + 1;
            _invoices.Add(invoice);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Id == id);
            return View(invoice);
        }

        [HttpPost]
        public IActionResult Edit(Invoice invoice)
        {
            var existing = _invoices.FirstOrDefault(i => i.Id == invoice.Id);
            if (existing != null)
            {
                existing.Number = invoice.Number;
                existing.Customer = invoice.Customer;
                existing.Date = invoice.Date;
                existing.Amount = invoice.Amount;
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Id == id);
            return View(invoice);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var invoice = _invoices.FirstOrDefault(i => i.Id == id);
            if (invoice != null)
                _invoices.Remove(invoice);

            return RedirectToAction(nameof(Index));
        }
    }
}