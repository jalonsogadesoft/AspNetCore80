# Proyecto ASP.NET Core 8 - Aplicación Mínima

## Cómo ejecutar
1. Tener .NET 8 instalado
2. Ejecutar:
   dotnet run
3. Abrir navegador:
   http://localhost:5000

## Endpoints
- /        -> mensaje usando servicio
- /config  -> lectura de configuración

## Conceptos incluidos
- WebApplicationBuilder
- Middleware
- DI (Dependency Injection)
- Configuración appsettings.json
- Minimal APIs
