using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// ==============================
// CREACIÓN DEL BUILDER
// ==============================
// WebApplication.CreateBuilder crea el contenedor base de la app
var builder = WebApplication.CreateBuilder(args);

// ==============================
// CONFIGURACIÓN (appsettings.json)
// ==============================
// Lectura de valores de configuración
string mensajeConfig = builder.Configuration["MiConfiguracion:Mensaje"] ?? "(sin valor)";

// ==============================
// INYECCIÓN DE DEPENDENCIAS
// ==============================
// Ejemplo de servicio
builder.Services.AddSingleton<IMiServicio, MiServicio>();

// ==============================
// CONSTRUCCIÓN DE LA APP
// ==============================
var app = builder.Build();

// ==============================
// MIDDLEWARE PERSONALIZADO
// ==============================
app.Use(async (context, next) =>
{
    // Código antes del siguiente middleware
    Console.WriteLine("[Middleware] Antes de next()");

    await next(); // Llama al siguiente middleware

    // Código después del siguiente middleware
    Console.WriteLine("[Middleware] Después de next()");
});

// Middleware adicional simple
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("X-Demo", "ASP.NET Core 8 Middleware");
    await next();
});

// ==============================
// ENDPOINTS (Minimal APIs)
// ==============================
app.MapGet("/", (IMiServicio servicio) =>
{
    return Results.Text($"Hola desde ASP.NET Core 8! Servicio dice: {servicio.GetMensaje()}");
});

app.MapGet("/config", () =>
{
    return Results.Text($"Mensaje desde appsettings.json: {mensajeConfig}");
});

// ==============================
// EJECUCIÓN DE LA APP
// ==============================
app.Run();

// ==============================
// CLASES AUXILIARES
// ==============================
public interface IMiServicio
{
    string GetMensaje();
}

public class MiServicio : IMiServicio
{
    public string GetMensaje()
    {
        return "Este mensaje proviene de un servicio inyectado";
    }
}
