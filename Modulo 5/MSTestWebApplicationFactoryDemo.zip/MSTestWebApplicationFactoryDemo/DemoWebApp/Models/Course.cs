namespace DemoWebApp.Models;

public class Course
{
    public int Id { get; init; }

    public required string Title { get; init; }

    public required string Level { get; init; }
}
