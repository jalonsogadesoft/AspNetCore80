using DemoWebApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DemoWebApp.Controllers;

public class CoursesController(ICourseCatalogService catalogService) : Controller
{
    public IActionResult Index()
    {
        var courses = catalogService.GetAll();
        return View(courses);
    }

    public IActionResult Details(int id)
    {
        var course = catalogService.GetById(id);
        if (course is null)
        {
            return NotFound();
        }

        return View(course);
    }

    [Authorize]
    public IActionResult Enroll(int id)
    {
        var course = catalogService.GetById(id);
        if (course is null)
        {
            return NotFound();
        }

        return Content($"Inscripcion completada en: {course.Title}");
    }

    public IActionResult GoToCatalog() => RedirectToAction(nameof(Index));
}
