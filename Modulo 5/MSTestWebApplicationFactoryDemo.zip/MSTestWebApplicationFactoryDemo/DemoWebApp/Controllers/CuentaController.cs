using Microsoft.AspNetCore.Mvc;

namespace DemoWebApp.Controllers;

public class CuentaController : Controller
{
    public IActionResult Login(string? returnUrl = null)
    {
        return Content($"Login requerido. ReturnUrl={returnUrl ?? "/"}");
    }
}
