using DemoWebApp.Models;

namespace DemoWebApp.Services;

public interface ICourseCatalogService
{
    IReadOnlyCollection<Course> GetAll();

    Course? GetById(int id);
}
