using DemoWebApp.Models;

namespace DemoWebApp.Services;

public class InMemoryCourseCatalogService : ICourseCatalogService
{
    private static readonly IReadOnlyCollection<Course> Courses =
    [
        new Course { Id = 1, Title = "Fundamentos de pruebas en ASP.NET Core", Level = "Basico" },
        new Course { Id = 2, Title = "Integracion con WebApplicationFactory", Level = "Intermedio" },
        new Course { Id = 3, Title = "Tecnicas de pruebas de seguridad", Level = "Avanzado" }
    ];

    public IReadOnlyCollection<Course> GetAll() => Courses;

    public Course? GetById(int id) => Courses.FirstOrDefault(c => c.Id == id);
}
