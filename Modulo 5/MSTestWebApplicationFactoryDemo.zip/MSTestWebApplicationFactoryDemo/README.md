# Demo didactica: MSTest + WebApplicationFactory (ASP.NET Core 8)

Este ejemplo muestra una aplicacion **ASP.NET Core 8 (MVC + Razor)** y un proyecto de pruebas de integracion con **MSTest** usando **WebApplicationFactory**.

## Que cubre

1. Arranque completo de la app en memoria con `WebApplicationFactory<Program>`.
2. Pruebas de rutas y contenido HTML real (`GET /`, `404` en ruta inexistente).
3. Pruebas de redireccion (`AllowAutoRedirect = false`).
4. Reemplazo de dependencias con `ConfigureTestServices` para aislar escenarios.
5. Pruebas de endpoints protegidos con `Authorize`:
   - sin autenticacion (redirect a login),
   - con autenticacion fake (`TestAuthHandler`) en entorno de pruebas.

## Estructura

- `DemoWebApp`: app MVC + Razor.
- `DemoWebApp.Tests`: pruebas MSTest de integracion.

## Ejecutar

```bash
dotnet restore MSTestWebApplicationFactoryDemo.sln
dotnet test MSTestWebApplicationFactoryDemo.sln
```
