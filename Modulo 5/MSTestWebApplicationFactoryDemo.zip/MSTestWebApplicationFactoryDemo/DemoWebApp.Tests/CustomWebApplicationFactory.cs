using Microsoft.AspNetCore.Mvc.Testing;

namespace DemoWebApp.Tests;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
}
