using DemoWebApp.Models;
using DemoWebApp.Services;

namespace DemoWebApp.Tests;

public class FakeCourseCatalogService : ICourseCatalogService
{
    private readonly IReadOnlyCollection<Course> _courses =
    [
        new Course { Id = 101, Title = "Curso Fake para pruebas", Level = "Test" }
    ];

    public IReadOnlyCollection<Course> GetAll() => _courses;

    public Course? GetById(int id) => _courses.FirstOrDefault(c => c.Id == id);
}
