namespace CalidadSoftwareXunitDemo.Web.Models;

public class ShoppingCart
{
    public decimal Subtotal { get; init; }
    public int ItemCount { get; init; }
    public bool IsVipCustomer { get; init; }
    public string? CouponCode { get; init; }
}
