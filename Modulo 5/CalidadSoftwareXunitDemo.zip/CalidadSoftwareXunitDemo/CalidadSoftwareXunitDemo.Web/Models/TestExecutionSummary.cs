namespace CalidadSoftwareXunitDemo.Web.Models;

public class TestExecutionSummary
{
    public int TotalTests { get; init; }
    public int PassedTests { get; init; }
    public int CriticalBugs { get; init; }
    public int HighBugs { get; init; }
}
