namespace CalidadSoftwareXunitDemo.Web.Models;

public class QualityLabViewModel
{
    public required ShoppingCart SampleCart { get; init; }
    public required TestExecutionSummary SampleSummary { get; init; }
    public decimal CalculatedTotal { get; init; }
    public int QualityScore { get; init; }
    public IReadOnlyList<string> ReleaseChecklist { get; init; } = Array.Empty<string>();
}
