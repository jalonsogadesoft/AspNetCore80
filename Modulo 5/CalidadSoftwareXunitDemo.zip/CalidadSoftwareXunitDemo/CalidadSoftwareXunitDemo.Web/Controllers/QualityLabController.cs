using CalidadSoftwareXunitDemo.Web.Models;
using CalidadSoftwareXunitDemo.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace CalidadSoftwareXunitDemo.Web.Controllers;

public class QualityLabController : Controller
{
    private readonly IPricingQualityService _pricingQualityService;

    public QualityLabController(IPricingQualityService pricingQualityService)
    {
        _pricingQualityService = pricingQualityService;
    }

    public IActionResult Index()
    {
        var sampleCart = new ShoppingCart
        {
            Subtotal = 240m,
            ItemCount = 6,
            IsVipCustomer = true,
            CouponCode = "PROMO10"
        };

        var sampleSummary = new TestExecutionSummary
        {
            TotalTests = 120,
            PassedTests = 118,
            CriticalBugs = 0,
            HighBugs = 1
        };

        var model = new QualityLabViewModel
        {
            SampleCart = sampleCart,
            SampleSummary = sampleSummary,
            CalculatedTotal = _pricingQualityService.CalculateTotal(sampleCart),
            QualityScore = _pricingQualityService.CalculateQualityScore(sampleSummary),
            ReleaseChecklist = _pricingQualityService.BuildReleaseChecklist(sampleSummary)
        };

        return View(model);
    }
}
