using CalidadSoftwareXunitDemo.Web.Models;

namespace CalidadSoftwareXunitDemo.Web.Services;

public class PricingQualityService : IPricingQualityService
{
    private const decimal StandardShipping = 4.99m;

    public decimal CalculateTotal(ShoppingCart cart)
    {
        if (cart.Subtotal <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(cart.Subtotal), "El subtotal debe ser mayor que cero.");
        }

        if (cart.ItemCount <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(cart.ItemCount), "La cantidad de articulos debe ser mayor que cero.");
        }

        decimal discount = cart.IsVipCustomer ? 0.10m : 0m;
        var normalizedCoupon = cart.CouponCode?.Trim().ToUpperInvariant();

        if (!string.IsNullOrWhiteSpace(normalizedCoupon))
        {
            discount += normalizedCoupon switch
            {
                "PROMO5" => 0.05m,
                "PROMO10" => 0.10m,
                _ => throw new ArgumentException("El cupon no es valido.", nameof(cart.CouponCode))
            };
        }

        discount = Math.Min(discount, 0.25m);

        var subtotalWithDiscount = cart.Subtotal * (1 - discount);
        var shipping = IsEligibleForFreeShipping(cart) ? 0m : StandardShipping;

        return Math.Round(subtotalWithDiscount + shipping, 2, MidpointRounding.AwayFromZero);
    }

    public bool IsEligibleForFreeShipping(ShoppingCart cart)
        => cart.IsVipCustomer || cart.Subtotal >= 100m || cart.ItemCount >= 8;

    public int CalculateQualityScore(TestExecutionSummary summary)
    {
        if (summary.TotalTests <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(summary.TotalTests), "El total de pruebas debe ser mayor que cero.");
        }

        if (summary.PassedTests < 0 || summary.PassedTests > summary.TotalTests)
        {
            throw new ArgumentOutOfRangeException(nameof(summary.PassedTests), "Las pruebas aprobadas deben estar entre cero y el total.");
        }

        if (summary.CriticalBugs < 0 || summary.HighBugs < 0)
        {
            throw new ArgumentOutOfRangeException(nameof(summary), "La cantidad de bugs no puede ser negativa.");
        }

        var passRate = summary.PassedTests / (decimal)summary.TotalTests;
        var baseScore = passRate * 100m;
        var bugsPenalty = (summary.CriticalBugs * 15m) + (summary.HighBugs * 5m);
        var calculatedScore = (int)Math.Round(baseScore - bugsPenalty, MidpointRounding.AwayFromZero);

        return Math.Clamp(calculatedScore, 0, 100);
    }

    public IReadOnlyList<string> BuildReleaseChecklist(TestExecutionSummary summary)
    {
        var checklist = new List<string>();

        if (summary.PassedTests != summary.TotalTests)
        {
            checklist.Add("No todas las pruebas han sido aprobadas.");
        }

        if (summary.CriticalBugs > 0)
        {
            checklist.Add("Existen bugs criticos pendientes.");
        }

        if (CalculateQualityScore(summary) < 85)
        {
            checklist.Add("El quality score no alcanza el umbral de salida (85).");
        }

        if (checklist.Count == 0)
        {
            checklist.Add("Release aprobado: calidad validada para despliegue.");
        }

        return checklist;
    }
}
