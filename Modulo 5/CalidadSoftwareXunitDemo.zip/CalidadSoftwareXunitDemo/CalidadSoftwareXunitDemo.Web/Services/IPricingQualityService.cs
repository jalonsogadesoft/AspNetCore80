using CalidadSoftwareXunitDemo.Web.Models;

namespace CalidadSoftwareXunitDemo.Web.Services;

public interface IPricingQualityService
{
    decimal CalculateTotal(ShoppingCart cart);
    bool IsEligibleForFreeShipping(ShoppingCart cart);
    int CalculateQualityScore(TestExecutionSummary summary);
    IReadOnlyList<string> BuildReleaseChecklist(TestExecutionSummary summary);
}
