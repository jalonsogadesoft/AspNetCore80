using CalidadSoftwareXunitDemo.Tests.Collections;
using CalidadSoftwareXunitDemo.Tests.Fixtures;
using CalidadSoftwareXunitDemo.Web.Models;

namespace CalidadSoftwareXunitDemo.Tests.Services;

[Collection("Release data")]
public class PricingQualityServiceTests : IClassFixture<PricingFixture>
{
    private readonly PricingFixture _pricingFixture;
    private readonly ReleaseThresholdFixture _releaseThresholdFixture;

    public PricingQualityServiceTests(PricingFixture pricingFixture, ReleaseThresholdFixture releaseThresholdFixture)
    {
        _pricingFixture = pricingFixture;
        _releaseThresholdFixture = releaseThresholdFixture;
    }

    [Fact]
    [Trait("Category", "BusinessRules")]
    public void CalculateTotal_ShouldApplyVipAndCouponDiscount_WhenCartIsEligibleForFreeShipping()
    {
        var total = _pricingFixture.Service.CalculateTotal(_pricingFixture.VipCartWithCoupon);

        Assert.Equal(160m, total);
    }

    [Theory]
    [InlineData(99.99, 2, false, false)]
    [InlineData(100, 1, false, true)]
    [InlineData(50, 8, false, true)]
    [InlineData(10, 1, true, true)]
    public void IsEligibleForFreeShipping_ShouldEvaluateRulesCorrectly(
        decimal subtotal,
        int itemCount,
        bool isVip,
        bool expected)
    {
        var cart = new ShoppingCart
        {
            Subtotal = subtotal,
            ItemCount = itemCount,
            IsVipCustomer = isVip
        };

        var result = _pricingFixture.Service.IsEligibleForFreeShipping(cart);

        Assert.Equal(expected, result);
    }

    public static IEnumerable<object[]> InvalidCartData()
    {
        yield return new object[] { 0m, 3 };
        yield return new object[] { -1m, 2 };
        yield return new object[] { 10m, 0 };
    }

    [Theory]
    [MemberData(nameof(InvalidCartData))]
    public void CalculateTotal_ShouldThrowArgumentOutOfRangeException_ForInvalidCart(decimal subtotal, int itemCount)
    {
        var cart = new ShoppingCart
        {
            Subtotal = subtotal,
            ItemCount = itemCount,
            IsVipCustomer = false
        };

        Assert.Throws<ArgumentOutOfRangeException>(() => _pricingFixture.Service.CalculateTotal(cart));
    }

    [Theory]
    [ClassData(typeof(InvalidCouponData))]
    public void CalculateTotal_ShouldThrowArgumentException_ForInvalidCoupons(string coupon)
    {
        var cart = new ShoppingCart
        {
            Subtotal = 50m,
            ItemCount = 1,
            IsVipCustomer = false,
            CouponCode = coupon
        };

        Assert.Throws<ArgumentException>(() => _pricingFixture.Service.CalculateTotal(cart));
    }

    [Fact]
    public void CalculateQualityScore_ShouldClampResultBetweenZeroAndHundred()
    {
        var summary = new TestExecutionSummary
        {
            TotalTests = 20,
            PassedTests = 20,
            CriticalBugs = 10,
            HighBugs = 5
        };

        var score = _pricingFixture.Service.CalculateQualityScore(summary);

        Assert.Equal(0, score);
    }

    [Fact]
    public void BuildReleaseChecklist_ShouldReturnApprovalMessage_WhenQualityIsReady()
    {
        var summary = new TestExecutionSummary
        {
            TotalTests = 50,
            PassedTests = 50,
            CriticalBugs = 0,
            HighBugs = 0
        };

        var score = _pricingFixture.Service.CalculateQualityScore(summary);
        var checklist = _pricingFixture.Service.BuildReleaseChecklist(summary);

        Assert.True(score >= _releaseThresholdFixture.ProductionScoreThreshold);
        Assert.Collection(checklist,
            item => Assert.Equal("Release aprobado: calidad validada para despliegue.", item));
    }
}

public class InvalidCouponData : IEnumerable<object[]>
{
    public IEnumerator<object[]> GetEnumerator()
    {
        yield return new object[] { "NOPE" };
        yield return new object[] { "promo-20" };
        yield return new object[] { "BLACKFRIDAY" };
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();
}
