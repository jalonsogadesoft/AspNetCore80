using CalidadSoftwareXunitDemo.Web.Controllers;
using CalidadSoftwareXunitDemo.Web.Models;
using CalidadSoftwareXunitDemo.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace CalidadSoftwareXunitDemo.Tests.Controllers;

public class QualityLabControllerTests
{
    [Fact]
    public void Index_ShouldReturnViewWithExpectedModel()
    {
        var fakeService = new FakePricingQualityService();
        var controller = new QualityLabController(fakeService);

        var result = controller.Index();

        var viewResult = Assert.IsType<ViewResult>(result);
        var model = Assert.IsType<QualityLabViewModel>(viewResult.Model);
        Assert.Equal(123.45m, model.CalculatedTotal);
        Assert.Equal(91, model.QualityScore);
        Assert.Equal("Checklist generado por fake service.", model.ReleaseChecklist.Single());
        Assert.True(fakeService.CalculateTotalCalled);
        Assert.True(fakeService.CalculateQualityScoreCalled);
        Assert.True(fakeService.BuildReleaseChecklistCalled);
    }

    private sealed class FakePricingQualityService : IPricingQualityService
    {
        public bool CalculateTotalCalled { get; private set; }
        public bool CalculateQualityScoreCalled { get; private set; }
        public bool BuildReleaseChecklistCalled { get; private set; }

        public decimal CalculateTotal(ShoppingCart cart)
        {
            CalculateTotalCalled = true;
            return 123.45m;
        }

        public bool IsEligibleForFreeShipping(ShoppingCart cart) => true;

        public int CalculateQualityScore(TestExecutionSummary summary)
        {
            CalculateQualityScoreCalled = true;
            return 91;
        }

        public IReadOnlyList<string> BuildReleaseChecklist(TestExecutionSummary summary)
        {
            BuildReleaseChecklistCalled = true;
            return new[] { "Checklist generado por fake service." };
        }
    }
}
