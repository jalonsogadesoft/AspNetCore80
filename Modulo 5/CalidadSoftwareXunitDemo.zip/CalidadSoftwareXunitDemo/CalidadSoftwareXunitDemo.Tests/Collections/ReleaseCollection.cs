using CalidadSoftwareXunitDemo.Tests.Fixtures;

namespace CalidadSoftwareXunitDemo.Tests.Collections;

[CollectionDefinition("Release data")]
public class ReleaseCollection : ICollectionFixture<ReleaseThresholdFixture>
{
}
