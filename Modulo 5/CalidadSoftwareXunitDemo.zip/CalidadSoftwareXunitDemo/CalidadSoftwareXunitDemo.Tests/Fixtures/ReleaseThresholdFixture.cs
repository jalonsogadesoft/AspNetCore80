namespace CalidadSoftwareXunitDemo.Tests.Fixtures;

public class ReleaseThresholdFixture
{
    public int ProductionScoreThreshold => 85;
}
