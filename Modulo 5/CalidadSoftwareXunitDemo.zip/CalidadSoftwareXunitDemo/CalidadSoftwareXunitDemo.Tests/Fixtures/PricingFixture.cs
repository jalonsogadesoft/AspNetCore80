using CalidadSoftwareXunitDemo.Web.Models;
using CalidadSoftwareXunitDemo.Web.Services;

namespace CalidadSoftwareXunitDemo.Tests.Fixtures;

public class PricingFixture
{
    public IPricingQualityService Service { get; } = new PricingQualityService();

    public ShoppingCart VipCartWithCoupon { get; } = new()
    {
        Subtotal = 200m,
        ItemCount = 4,
        IsVipCustomer = true,
        CouponCode = "PROMO10"
    };
}
