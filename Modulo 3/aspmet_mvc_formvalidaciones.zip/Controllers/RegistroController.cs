
using Microsoft.AspNetCore.Mvc;
using aspmet_mvc_formvalidaciones.Models;

namespace aspmet_mvc_formvalidaciones.Controllers
{
    public class RegistroController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new RegistroViewModel());
        }

        [HttpPost]
        public IActionResult Index(RegistroViewModel model)
        {
            if (model.Nombre == "Admin")
            {
                ModelState.AddModelError("", "Nombre no permitido");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            TempData["Mensaje"] = "Registro correcto";
            return RedirectToAction("Index");
        }
    }
}
