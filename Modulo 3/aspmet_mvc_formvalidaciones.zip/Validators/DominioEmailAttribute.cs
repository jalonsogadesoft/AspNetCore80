
using System.ComponentModel.DataAnnotations;

namespace aspmet_mvc_formvalidaciones.Validators
{
    public class DominioEmailAttribute : ValidationAttribute
    {
        public string DominioPermitido { get; set; }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var email = value as string;

            if (email != null && !email.EndsWith($"@{DominioPermitido}"))
            {
                return new ValidationResult($"El email debe ser del dominio {DominioPermitido}");
            }

            return ValidationResult.Success;
        }
    }
}
