
using System.ComponentModel.DataAnnotations;

namespace aspmet_mvc_formvalidaciones.Models
{
    public class RegistroViewModel : IValidatableObject
    {
        [Required]
        public string Nombre { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Compare("Password")]
        public string ConfirmarPassword { get; set; }

        [Range(18,100)]
        public int Edad { get; set; }

        public string Pais { get; set; }

        public bool AceptaTerminos { get; set; }

        public DateTime FechaNacimiento { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (FechaNacimiento > DateTime.Now.AddYears(-18))
            {
                yield return new ValidationResult("Debes ser mayor de edad", new[] { nameof(FechaNacimiento) });
            }

            if (!AceptaTerminos)
            {
                yield return new ValidationResult("Debes aceptar los términos", new[] { nameof(AceptaTerminos) });
            }
        }
    }
}
