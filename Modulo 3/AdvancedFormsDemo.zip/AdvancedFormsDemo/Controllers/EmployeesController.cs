using AdvancedFormsDemo.Models;
using AdvancedFormsDemo.Services;
using Microsoft.AspNetCore.Mvc;

namespace AdvancedFormsDemo.Controllers;

public class EmployeesController : Controller
{
    private readonly IEmployeeService _service;

    public EmployeesController(IEmployeeService service)
    {
        _service = service;
    }

    // ─── INDEX ────────────────────────────────────────────────────────────────

    public IActionResult Index()
    {
        var employees = _service.GetAll();
        return View(employees);
    }

    // ─── DETAILS ──────────────────────────────────────────────────────────────

    public IActionResult Details(int id)
    {
        var employee = _service.GetById(id);
        if (employee is null) return NotFound();
        return View(employee);
    }

    // ─── CREATE ───────────────────────────────────────────────────────────────

    [HttpGet]
    public IActionResult Create()
    {
        return View(new Employee());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Employee employee)
    {
        if (!ModelState.IsValid)
            return View(employee);

        _service.Add(employee);
        TempData["Success"] = $"Empleado '{employee.FullName}' creado correctamente.";
        return RedirectToAction(nameof(Index));
    }

    // ─── EDIT ─────────────────────────────────────────────────────────────────

    [HttpGet]
    public IActionResult Edit(int id)
    {
        var employee = _service.GetById(id);
        if (employee is null) return NotFound();
        return View(employee);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, Employee employee)
    {
        if (id != employee.Id) return BadRequest();

        if (!ModelState.IsValid)
            return View(employee);

        if (!_service.Update(employee))
            return NotFound();

        TempData["Success"] = $"Empleado '{employee.FullName}' actualizado correctamente.";
        return RedirectToAction(nameof(Index));
    }

    // ─── DELETE ───────────────────────────────────────────────────────────────

    [HttpGet]
    public IActionResult Delete(int id)
    {
        var employee = _service.GetById(id);
        if (employee is null) return NotFound();
        return View(employee);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        var employee = _service.GetById(id);
        if (employee is null) return NotFound();

        var name = employee.FullName;
        _service.Delete(id);
        TempData["Success"] = $"Empleado '{name}' eliminado correctamente.";
        return RedirectToAction(nameof(Index));
    }

    // ─── VALIDACIÓN REMOTA (AJAX) ─────────────────────────────────────────────

    /// <summary>
    /// Endpoint llamado por el atributo [Remote] para comprobar unicidad del email.
    /// Devuelve <c>true</c> si el email está disponible, o un mensaje de error.
    /// </summary>
    [HttpGet]
    public IActionResult IsEmailAvailable(string email, int id = 0)
    {
        if (string.IsNullOrWhiteSpace(email))
            return Json(true);

        var exists = _service.EmailExists(email, excludeId: id);
        return Json(!exists
            ? true
            : (object)"Este correo electrónico ya está registrado por otro empleado.");
    }

    /// <summary>
    /// Endpoint AJAX para obtener el rango de salario permitido según el cargo.
    /// Usado desde JavaScript para mostrar ayuda dinámica al usuario.
    /// </summary>
    [HttpGet]
    public IActionResult GetSalaryRange(string position)
    {
        var ranges = new Dictionary<string, (decimal Min, decimal Max)>
        {
            ["Becario"]  = (600m,    1_400m),
            ["Junior"]   = (1_400m,  2_800m),
            ["Senior"]   = (2_800m,  6_000m),
            ["Jefe"]     = (5_000m,  12_000m),
            ["Director"] = (10_000m, 50_000m),
        };

        if (!string.IsNullOrEmpty(position) && ranges.TryGetValue(position, out var range))
            return Json(new { min = range.Min, max = range.Max });

        return Json(new { min = (decimal?)null, max = (decimal?)null });
    }
}
