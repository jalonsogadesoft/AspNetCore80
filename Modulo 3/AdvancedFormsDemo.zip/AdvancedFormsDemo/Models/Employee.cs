using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using AdvancedFormsDemo.Models.Enums;
using AdvancedFormsDemo.Validation;

namespace AdvancedFormsDemo.Models;

/// <summary>
/// Modelo Empleado: demuestra validaciones a nivel de campo (atributos) y
/// a nivel de registro (IValidatableObject / validaciones cruzadas entre campos).
/// </summary>
public class Employee : IValidatableObject
{
    public int Id { get; set; }

    // ─── DATOS PERSONALES ────────────────────────────────────────────────────

    [Required(ErrorMessage = "El nombre completo es obligatorio")]
    [StringLength(100, MinimumLength = 3,
        ErrorMessage = "El nombre debe tener entre 3 y 100 caracteres")]
    [Display(Name = "Nombre completo")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "El correo electrónico es obligatorio")]
    [EmailAddress(ErrorMessage = "Formato de correo electrónico no válido")]
    [Display(Name = "Correo electrónico")]
    // Validación remota: comprueba unicidad en el servidor sin recargar la página
    [Remote(action: "IsEmailAvailable", controller: "Employees",
            AdditionalFields = nameof(Id),
            ErrorMessage = "Este correo electrónico ya está registrado")]
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// NIF/NIE validado con atributo personalizado que también emite reglas
    /// para jQuery Validate (IClientModelValidator).
    /// </summary>
    [Required(ErrorMessage = "El NIF/NIE es obligatorio")]
    [Display(Name = "NIF / NIE")]
    [ValidNif(ErrorMessage = "El formato del NIF/NIE no es válido (ej: 12345678Z)")]
    public string Nif { get; set; } = string.Empty;

    [Required(ErrorMessage = "La fecha de nacimiento es obligatoria")]
    [DataType(DataType.Date)]
    [Display(Name = "Fecha de nacimiento")]
    // Atributo personalizado: verifica edad mínima y también valida en cliente
    [MinimumAge(18, ErrorMessage = "El empleado debe ser mayor de 18 años")]
    public DateTime BirthDate { get; set; }

    // ─── DATOS LABORALES ─────────────────────────────────────────────────────

    [Required(ErrorMessage = "El departamento es obligatorio")]
    [Display(Name = "Departamento")]
    public Department Department { get; set; }

    [Required(ErrorMessage = "El cargo es obligatorio")]
    [Display(Name = "Cargo")]
    public Position Position { get; set; }

    [Required(ErrorMessage = "El salario es obligatorio")]
    [Range(0.01, 99999.99, ErrorMessage = "El salario debe estar entre 0,01 € y 99.999,99 €")]
    [DataType(DataType.Currency)]
    [Display(Name = "Salario mensual (€)")]
    public decimal Salary { get; set; }

    [Required(ErrorMessage = "La fecha de incorporación es obligatoria")]
    [DataType(DataType.Date)]
    [Display(Name = "Fecha de incorporación")]
    public DateTime StartDate { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Fecha de baja")]
    public DateTime? EndDate { get; set; }

    [Required(ErrorMessage = "El estado es obligatorio")]
    [Display(Name = "Estado")]
    public EmployeeStatus Status { get; set; }

    [Display(Name = "Teléfono de contacto")]
    [Phone(ErrorMessage = "Número de teléfono no válido")]
    [StringLength(15, ErrorMessage = "El teléfono no puede superar los 15 caracteres")]
    public string? Phone { get; set; }

    [Display(Name = "Observaciones")]
    [StringLength(500, ErrorMessage = "Las observaciones no pueden superar los 500 caracteres")]
    [DataType(DataType.MultilineText)]
    public string? Notes { get; set; }

    /// <summary>
    /// Atributo personalizado que valida que la casilla esté marcada (true).
    /// Registra también una regla de jQuery Validate en cliente.
    /// </summary>
    [MustBeTrue(ErrorMessage = "Debe aceptar la política de tratamiento de datos")]
    [Display(Name = "Acepto la política de tratamiento de datos")]
    public bool AcceptsDataPolicy { get; set; }

    // ─── VALIDACIONES CRUZADAS (NIVEL REGISTRO) ───────────────────────────────

    /// <summary>
    /// IValidatableObject permite validar reglas que involucran múltiples
    /// campos simultáneamente. Solo se ejecutan si las validaciones de
    /// campo individuales han pasado.
    /// </summary>
    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Regla 1: Fecha de baja obligatoria si el estado es Inactivo
        if (Status == EmployeeStatus.Inactivo && !EndDate.HasValue)
        {
            yield return new ValidationResult(
                "La fecha de baja es obligatoria cuando el estado es 'Inactivo'.",
                new[] { nameof(EndDate) });
        }

        // Regla 2: Fecha de baja debe ser posterior a la fecha de incorporación
        if (EndDate.HasValue && EndDate.Value <= StartDate)
        {
            yield return new ValidationResult(
                "La fecha de baja debe ser posterior a la fecha de incorporación.",
                new[] { nameof(EndDate) });
        }

        // Regla 3: Fecha de incorporación no puede ser anterior a los 16 años del empleado
        if (BirthDate != default && StartDate < BirthDate.AddYears(16))
        {
            yield return new ValidationResult(
                "El empleado no puede incorporarse antes de cumplir 16 años.",
                new[] { nameof(StartDate) });
        }

        // Regla 4: El salario debe estar dentro del rango permitido según el cargo
        var salaryRanges = new Dictionary<Position, (decimal Min, decimal Max)>
        {
            [Position.Becario] = (600m,   1_400m),
            [Position.Junior]  = (1_400m, 2_800m),
            [Position.Senior]  = (2_800m, 6_000m),
            [Position.Jefe]    = (5_000m, 12_000m),
            [Position.Director]= (10_000m, 50_000m),
        };

        if (salaryRanges.TryGetValue(Position, out var range))
        {
            if (Salary < range.Min || Salary > range.Max)
            {
                yield return new ValidationResult(
                    $"Para el cargo '{Position}', el salario mensual debe estar entre {range.Min:N2} € y {range.Max:N2} €.",
                    new[] { nameof(Salary), nameof(Position) });
            }
        }
    }
}
