namespace AdvancedFormsDemo.Models.Enums;

public enum EmployeeStatus
{
    Activo,
    Inactivo,
    Suspendido
}
