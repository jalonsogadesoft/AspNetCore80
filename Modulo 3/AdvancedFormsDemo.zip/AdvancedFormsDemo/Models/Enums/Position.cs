namespace AdvancedFormsDemo.Models.Enums;

public enum Position
{
    Becario,
    Junior,
    Senior,
    Jefe,
    Director
}
