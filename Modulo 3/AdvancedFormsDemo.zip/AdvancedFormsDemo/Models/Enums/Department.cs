namespace AdvancedFormsDemo.Models.Enums;

public enum Department
{
    Tecnologia,
    RecursosHumanos,
    Finanzas,
    Marketing,
    Operaciones,
    Juridico
}
