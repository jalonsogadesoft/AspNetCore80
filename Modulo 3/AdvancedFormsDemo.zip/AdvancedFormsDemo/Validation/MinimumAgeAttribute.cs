using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace AdvancedFormsDemo.Validation;

/// <summary>
/// Valida que la fecha del campo represente una persona cuya edad sea al menos
/// <see cref="MinAge"/> años. Implementa IClientModelValidator para emitir
/// data-val-minage y data-val-minage-years al HTML, permitiendo validación en cliente.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public sealed class MinimumAgeAttribute : ValidationAttribute, IClientModelValidator
{
    public int MinAge { get; }

    public MinimumAgeAttribute(int minAge)
    {
        MinAge = minAge;
        ErrorMessage = $"Debe ser mayor de {minAge} años";
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
    {
        if (value is not DateTime date)
            return ValidationResult.Success;

        var cutoff = DateTime.Today.AddYears(-MinAge);
        if (date > cutoff)
            return new ValidationResult(FormatErrorMessage(ctx.DisplayName));

        return ValidationResult.Success;
    }

    /// <summary>
    /// Emite data-val-minage y data-val-minage-years para que el script cliente
    /// pueda calcular la edad mínima sin llamada AJAX.
    /// </summary>
    public void AddValidation(ClientModelValidationContext context)
    {
        MergeAttribute(context.Attributes, "data-val", "true");
        MergeAttribute(context.Attributes, "data-val-minage", ErrorMessage!);
        MergeAttribute(context.Attributes, "data-val-minage-years", MinAge.ToString());
    }

    private static void MergeAttribute(IDictionary<string, string> attrs, string key, string value)
    {
        if (!attrs.ContainsKey(key))
            attrs.Add(key, value);
    }
}
