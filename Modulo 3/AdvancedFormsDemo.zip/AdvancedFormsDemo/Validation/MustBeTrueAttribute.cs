using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace AdvancedFormsDemo.Validation;

/// <summary>
/// Valida que una propiedad booleana sea <c>true</c>.
/// Útil para checkboxes de aceptación de términos y condiciones.
/// Registra la regla "musttrue" en jQuery Validate para validación cliente.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public sealed class MustBeTrueAttribute : ValidationAttribute, IClientModelValidator
{
    protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
    {
        if (value is bool boolValue && boolValue)
            return ValidationResult.Success;

        return new ValidationResult(ErrorMessage ?? "Este campo debe estar marcado");
    }

    public void AddValidation(ClientModelValidationContext context)
    {
        MergeAttribute(context.Attributes, "data-val", "true");
        MergeAttribute(context.Attributes, "data-val-musttrue", ErrorMessage ?? "Este campo debe estar marcado");
    }

    private static void MergeAttribute(IDictionary<string, string> attrs, string key, string value)
    {
        if (!attrs.ContainsKey(key))
            attrs.Add(key, value);
    }
}
