using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace AdvancedFormsDemo.Validation;

/// <summary>
/// Valida que el valor sea un NIF (8 dígitos + letra) o NIE (X/Y/Z + 7 dígitos + letra) español.
/// Implementa IClientModelValidator para emitir atributos data-val-* que jQuery Validate
/// puede procesar en el cliente sin llamada al servidor.
/// </summary>
[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public sealed class ValidNifAttribute : ValidationAttribute, IClientModelValidator
{
    // Expresión regular: NIF (12345678A) o NIE (X1234567A / Y / Z)
    private static readonly Regex NifRegex =
        new(@"^[0-9XYZ]\d{7}[TRWAGMYFPDXBNJZSQVHLCKE]$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly string NifLetters = "TRWAGMYFPDXBNJZSQVHLCKE";

    protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
    {
        if (value is not string nif || string.IsNullOrWhiteSpace(nif))
            return ValidationResult.Success; // Required se encarga del nulo

        nif = nif.Trim().ToUpperInvariant();

        if (!NifRegex.IsMatch(nif))
            return new ValidationResult(ErrorMessage ?? "NIF/NIE no válido");

        if (!VerifyCheckLetter(nif))
            return new ValidationResult(ErrorMessage ?? "La letra del NIF/NIE no es correcta");

        return ValidationResult.Success;
    }

    private static bool VerifyCheckLetter(string nif)
    {
        int number;
        if (nif[0] == 'X') number = int.Parse("0" + nif.Substring(1, 7));
        else if (nif[0] == 'Y') number = int.Parse("1" + nif.Substring(1, 7));
        else if (nif[0] == 'Z') number = int.Parse("2" + nif.Substring(1, 7));
        else if (!int.TryParse(nif.Substring(0, 8), out number)) return false;

        return nif[^1] == NifLetters[number % 23];
    }

    /// <summary>
    /// Registra la regla "validnif" en jQuery Validate Unobtrusive.
    /// El motor de jQuery usará el adaptador definido en employees-validation.js.
    /// </summary>
    public void AddValidation(ClientModelValidationContext context)
    {
        MergeAttribute(context.Attributes, "data-val", "true");
        MergeAttribute(context.Attributes, "data-val-validnif", ErrorMessage ?? "NIF/NIE no válido");
    }

    private static void MergeAttribute(IDictionary<string, string> attrs, string key, string value)
    {
        if (!attrs.ContainsKey(key))
            attrs.Add(key, value);
    }
}
