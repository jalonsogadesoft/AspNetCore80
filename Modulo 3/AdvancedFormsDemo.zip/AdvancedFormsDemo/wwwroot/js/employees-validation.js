/**
 * employees-validation.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Registra adaptadores de jQuery Validate Unobtrusive para los atributos
 * de validación personalizados del modelo Employee:
 *
 *   1. validnif    → ValidNifAttribute   → data-val-validnif
 *   2. minage      → MinimumAgeAttribute → data-val-minage / data-val-minage-years
 *   3. musttrue    → MustBeTrueAttribute → data-val-musttrue
 *
 * Además implementa lógica de UX dinámica:
 *   - Muestra rango salarial al seleccionar cargo (AJAX)
 *   - Resalta fecha de baja como requerida cuando estado = Inactivo
 *   - Muestra/oculta el resumen de errores del servidor
 * ─────────────────────────────────────────────────────────────────────────────
 */

(function ($) {
    "use strict";

    // ── 1. REGLA: validnif ────────────────────────────────────────────────────

    const NIF_LETTERS = "TRWAGMYFPDXBNJZSQVHLCKE";

    /**
     * Verifica el formato y letra de control de un NIF o NIE español.
     * @param {string} value  Valor del campo (se normaliza internamente).
     * @returns {boolean}
     */
    function isValidNif(value) {
        if (!value) return true; // «required» se encarga del vacío

        value = value.trim().toUpperCase();
        const regex = /^[0-9XYZ]\d{7}[TRWAGMYFPDXBNJZSQVHLCKE]$/i;
        if (!regex.test(value)) return false;

        let number;
        const first = value[0];
        if (first === "X") number = parseInt("0" + value.substring(1, 8));
        else if (first === "Y") number = parseInt("1" + value.substring(1, 8));
        else if (first === "Z") number = parseInt("2" + value.substring(1, 8));
        else number = parseInt(value.substring(0, 8));

        return value[8] === NIF_LETTERS[number % 23];
    }

    // Método jQuery Validate
    $.validator.addMethod("validnif", function (value) {
        return isValidNif(value);
    });

    // Adaptador Unobtrusive (mapea data-val-validnif → regla "validnif")
    $.validator.unobtrusive.adapters.addBool("validnif");

    // ── 2. REGLA: minage ──────────────────────────────────────────────────────

    /**
     * Valida que la fecha ingresada corresponda a alguien con al menos
     * `params.years` años de edad en el día de hoy.
     */
    $.validator.addMethod("minage", function (value, element, params) {
        if (!value) return true;

        const date = new Date(value);
        if (isNaN(date.getTime())) return false;

        const cutoff = new Date();
        cutoff.setFullYear(cutoff.getFullYear() - parseInt(params.years, 10));
        return date <= cutoff;
    });

    // Adaptador: data-val-minage-years → params.years
    $.validator.unobtrusive.adapters.add("minage", ["years"], function (options) {
        options.rules["minage"] = { years: options.params["years"] };
        options.messages["minage"] = options.message;
    });

    // ── 3. REGLA: musttrue ────────────────────────────────────────────────────

    $.validator.addMethod("musttrue", function (value, element) {
        return element.type === "checkbox" ? element.checked : value === "true";
    });

    $.validator.unobtrusive.adapters.addBool("musttrue");

    // ── 4. UX DINÁMICA ────────────────────────────────────────────────────────

    $(document).ready(function () {

        // 4a. Al cambiar el cargo, consultar rango salarial vía AJAX
        const $position   = $("#positionSelect");
        const $salaryHint = $("#salaryHint");
        const $salaryRange= $("#salaryRange");

        function updateSalaryHint() {
            const pos = $position.val();
            if (!pos) {
                $salaryHint.addClass("d-none");
                return;
            }
            $.getJSON("/Employees/GetSalaryRange", { position: pos })
                .done(function (data) {
                    if (data.min !== null) {
                        $salaryRange.text(
                            data.min.toLocaleString("es-ES", { minimumFractionDigits: 2 }) + " € — " +
                            data.max.toLocaleString("es-ES", { minimumFractionDigits: 2 }) + " €"
                        );
                        $salaryHint.removeClass("d-none");
                    } else {
                        $salaryHint.addClass("d-none");
                    }
                });
        }

        $position.on("change", updateSalaryHint);
        updateSalaryHint(); // inicializar si ya hay valor (modo edición)

        // 4b. Resaltar «Fecha de baja» como campo requerido cuando estado = Inactivo
        const $status     = $("#statusSelect");
        const $endDate    = $("#endDate");
        const $endLabel   = $("#endDateLabel");

        function toggleEndDateRequired() {
            const isInactive = $status.val() === "Inactivo";
            $endDate.closest(".col-md-4")
                    .find("label")
                    .toggleClass("required-label", isInactive);
            if (isInactive) {
                $endDate.attr("data-val-required-enddatecond",
                    "La fecha de baja es obligatoria cuando el estado es Inactivo");
            } else {
                $endDate.removeAttr("data-val-required-enddatecond");
            }
        }

        $status.on("change", toggleEndDateRequired);
        toggleEndDateRequired();

        // 4c. Mostrar/ocultar el resumen de errores del servidor
        const $summary = $("#validationSummary");
        if ($summary.length && $summary.find("li").length > 0) {
            $summary.removeClass("d-none");
        }

        // 4d. Aplicar clase Bootstrap de error/éxito en campos al validar
        const $form = $("#employeeForm");
        if ($form.length) {
            $form.on("blur", "input, select, textarea", function () {
                const $el = $(this);
                // jQuery Validate expone un método para re-validar un elemento
                $form.validate().element($el);

                const hasError = $el.hasClass("input-validation-error");
                $el.toggleClass("is-invalid", hasError)
                   .toggleClass("is-valid",  !hasError && $el.val() !== "");
            });
        }

    });

})(jQuery);
