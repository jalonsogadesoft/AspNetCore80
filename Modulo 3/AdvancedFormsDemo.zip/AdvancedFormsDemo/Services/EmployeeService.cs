using AdvancedFormsDemo.Models;
using AdvancedFormsDemo.Models.Enums;

namespace AdvancedFormsDemo.Services;

/// <summary>
/// Repositorio en memoria que simula la capa de datos.
/// En una aplicación real se sustituiría por EF Core / dapper, etc.
/// </summary>
public interface IEmployeeService
{
    IReadOnlyList<Employee> GetAll();
    Employee? GetById(int id);
    void Add(Employee employee);
    bool Update(Employee employee);
    bool Delete(int id);
    bool EmailExists(string email, int excludeId = 0);
}

public class EmployeeService : IEmployeeService
{
    private readonly List<Employee> _store;
    private int _nextId = 10;

    public EmployeeService()
    {
        // Datos de muestra para tener algo que mostrar en la lista
        _store = new List<Employee>
        {
            new()
            {
                Id = 1, FullName = "Ana García López",
                Email = "ana.garcia@empresa.es", Nif = "12345678Z",
                BirthDate = new DateTime(1990, 5, 15),
                Department = Department.Tecnologia, Position = Position.Senior,
                Salary = 3_500m, StartDate = new DateTime(2018, 3, 1),
                Status = EmployeeStatus.Activo, Phone = "600111222",
                Notes = "Desarrolladora full-stack senior.", AcceptsDataPolicy = true
            },
            new()
            {
                Id = 2, FullName = "Carlos Martínez Ruiz",
                Email = "carlos.martinez@empresa.es", Nif = "87654321X",
                BirthDate = new DateTime(1985, 11, 20),
                Department = Department.Finanzas, Position = Position.Jefe,
                Salary = 7_000m, StartDate = new DateTime(2015, 9, 15),
                Status = EmployeeStatus.Activo, Phone = "600333444",
                AcceptsDataPolicy = true
            },
            new()
            {
                Id = 3, FullName = "Lucía Fernández Díaz",
                Email = "lucia.fernandez@empresa.es", Nif = "11223344B",
                BirthDate = new DateTime(1999, 2, 28),
                Department = Department.Marketing, Position = Position.Junior,
                Salary = 1_800m, StartDate = new DateTime(2023, 1, 10),
                Status = EmployeeStatus.Activo, AcceptsDataPolicy = true
            }
        };
    }

    public IReadOnlyList<Employee> GetAll() => _store.AsReadOnly();

    public Employee? GetById(int id) => _store.FirstOrDefault(e => e.Id == id);

    public void Add(Employee employee)
    {
        employee.Id = _nextId++;
        _store.Add(employee);
    }

    public bool Update(Employee employee)
    {
        var index = _store.FindIndex(e => e.Id == employee.Id);
        if (index < 0) return false;
        _store[index] = employee;
        return true;
    }

    public bool Delete(int id)
    {
        var employee = _store.FirstOrDefault(e => e.Id == id);
        if (employee is null) return false;
        _store.Remove(employee);
        return true;
    }

    public bool EmailExists(string email, int excludeId = 0) =>
        _store.Any(e => e.Email.Equals(email, StringComparison.OrdinalIgnoreCase)
                        && e.Id != excludeId);
}
