
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder=WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(o=>o.UseSqlite("Data Source=app.db"));
builder.Services.AddControllersWithViews();
builder.Services.AddControllers();

var key=Encoding.ASCII.GetBytes("super_secret_key_12345");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(o=>{
 o.TokenValidationParameters=new TokenValidationParameters{
  ValidateIssuerSigningKey=true,
  IssuerSigningKey=new SymmetricSecurityKey(key),
  ValidateIssuer=false,
  ValidateAudience=false};});

builder.Services.AddAuthorization();

var app=builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapControllerRoute(name:"default",pattern:"{controller=Invoices}/{action=Index}/{id?}");
app.Run();

public class AppDbContext:DbContext{
 public AppDbContext(DbContextOptions<AppDbContext> o):base(o){}
 public DbSet<Invoice> Invoices=>Set<Invoice>();}

public class Invoice{public int Id{get;set;} public string Number{get;set;}=""; public string Customer{get;set;}=""; public decimal Amount{get;set;} public DateTime Date{get;set;}}
