
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;

[ApiController]
[Route("api/auth")]
public class AuthController:ControllerBase{
 [HttpPost("login")]
 public IActionResult Login(){
  var key=Encoding.ASCII.GetBytes("super_secret_key_12345");
  var token=new JwtSecurityTokenHandler().CreateToken(
   new SecurityTokenDescriptor{
    Subject=new ClaimsIdentity(new[]{new Claim(ClaimTypes.Name,"demo")}),
    Expires=DateTime.UtcNow.AddHours(1),
    SigningCredentials=new SigningCredentials(new SymmetricSecurityKey(key),SecurityAlgorithms.HmacSha256)});
  return Ok(new JwtSecurityTokenHandler().WriteToken(token));}}
