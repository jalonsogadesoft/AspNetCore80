
using Microsoft.AspNetCore.Mvc;

public class InvoicesController:Controller{
 private readonly AppDbContext _ctx;
 public InvoicesController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Invoices.ToList());
 public IActionResult Create()=>View();
 [HttpPost]
 public IActionResult Create(Invoice i){_ctx.Invoices.Add(i);_ctx.SaveChanges();return RedirectToAction("Index");}}
