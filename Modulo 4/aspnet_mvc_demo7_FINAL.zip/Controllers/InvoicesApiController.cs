
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

[ApiController]
[Route("api/invoices")]
[Authorize]
public class InvoicesApiController:ControllerBase{
 private readonly AppDbContext _ctx;
 public InvoicesApiController(AppDbContext ctx){_ctx=ctx;}
 [HttpGet] public IActionResult Get()=>Ok(_ctx.Invoices.ToList());}
