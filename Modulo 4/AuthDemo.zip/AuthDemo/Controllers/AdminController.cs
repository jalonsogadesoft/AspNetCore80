using AuthDemo.Authorization;
using AuthDemo.Models.Enums;
using AuthDemo.Models.ViewModels;
using AuthDemo.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthDemo.Controllers;

/// <summary>
/// Panel de administración. Demuestra:
/// - Autorización por rol: solo Administrador.
/// - Gestión de usuarios (cambio de estado y rol).
/// </summary>
[Authorize(Roles = "Administrador")]
public class AdminController : Controller
{
    private readonly IUserService _users;

    public AdminController(IUserService users) => _users = users;

    public IActionResult Index()
    {
        var vm = new AdminUserListViewModel
        {
            Users = _users.GetAll().Select(u => new AdminUserRow
            {
                Id           = u.Id,
                FullName     = u.FullName,
                Email        = u.Email,
                Role         = u.Role.ToString(),
                Department   = u.Department.ToString(),
                Status       = u.Status.ToString(),
                Age          = u.Age,
                YearsOfService = u.YearsOfService
            }).ToList()
        };
        return View(vm);
    }

    // ─── Cambiar estado ───────────────────────────────────────────────────────

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult ToggleStatus(int id, UserStatus status)
    {
        if (!_users.UpdateStatus(id, status))
            return NotFound();

        TempData["Success"] = $"Estado del usuario #{id} actualizado a '{status}'.";
        return RedirectToAction(nameof(Index));
    }

    // ─── Cambiar rol ──────────────────────────────────────────────────────────

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult ChangeRole(int id, UserRole role)
    {
        if (!_users.UpdateRole(id, role))
            return NotFound();

        TempData["Success"] = $"Rol del usuario #{id} actualizado a '{role}'.";
        return RedirectToAction(nameof(Index));
    }
}
