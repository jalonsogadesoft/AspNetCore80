using AuthDemo.Authorization;
using AuthDemo.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AuthDemo.Controllers;

/// <summary>
/// Endpoint API que emite un JWT.
/// Demuestra el patrón híbrido: Cookie para vistas MVC + JWT para API.
/// También acepta una solicitud con credenciales y devuelve el token en JSON.
/// </summary>
[Route("api/[controller]")]
[ApiController]
public class TokenController : ControllerBase
{
    private readonly IUserService _users;
    private readonly IJwtService  _jwt;

    public TokenController(IUserService users, IJwtService jwt)
    {
        _users = users;
        _jwt   = jwt;
    }

    /// <summary>
    /// POST /api/token — Solicita un JWT con email + password.
    /// Responde con el token y su tiempo de expiración.
    /// </summary>
    [HttpPost]
    [AllowAnonymous]
    public IActionResult Issue([FromBody] TokenRequest req)
    {
        var user = _users.ValidateCredentials(req.Email, req.Password);
        if (user is null)
            return Unauthorized(new { error = "Credenciales incorrectas o cuenta bloqueada." });

        var token = _jwt.GenerateToken(user);
        return Ok(new
        {
            token,
            type     = "Bearer",
            expireIn = 3600,
            user     = new { user.Id, user.Email, user.FullName, role = user.Role.ToString() }
        });
    }

    /// <summary>
    /// GET /api/token/me — Devuelve los claims del JWT Bearer presente en la cabecera.
    /// Protegido con JWT Bearer (no con Cookie).
    /// </summary>
    [HttpGet("me")]
    [Authorize(AuthenticationSchemes = "Bearer")]
    public IActionResult Me()
    {
        var claims = User.Claims
            .Select(c => new { c.Type, c.Value })
            .ToList();
        return Ok(new { claims });
    }
}

public record TokenRequest(string Email, string Password);
