using AuthDemo.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthDemo.Controllers;

/// <summary>
/// Informes financieros. Demuestra autorización basada en POLÍTICA con lógica OR compleja:
/// aprueba Administradores o Gerentes del departamento Finanzas que estén Activos.
/// La política "CanAccessFinanceReports" usa <see cref="FinanceReportHandler"/>.
/// </summary>
[Authorize(Policy = Policies.CanAccessFinanceReports)]
public class ReportsController : Controller
{
    public IActionResult Index() => View();

    /// <summary>
    /// Subinforme solo para Administradores (sobreescritura de política a nivel de acción).
    /// Demuestra que se pueden apilar varias políticas/roles en distintos niveles.
    /// </summary>
    [Authorize(Roles = "Administrador")]
    public IActionResult AuditLog() => View();
}
