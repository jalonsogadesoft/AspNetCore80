using AuthDemo.Authorization;
using AuthDemo.Models;
using AuthDemo.Models.ViewModels;
using AuthDemo.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AuthDemo.Controllers;

/// <summary>
/// Gestiona registro, inicio de sesión, cierre de sesión y perfil del usuario.
/// Usa autenticación por Cookie para las vistas MVC.
/// El JWT se genera también para demostrar su uso y se muestra en el perfil.
/// </summary>
public class AccountController : Controller
{
    private readonly IUserService    _users;
    private readonly IJwtService     _jwt;

    public AccountController(IUserService users, IJwtService jwt)
    {
        _users = users;
        _jwt   = jwt;
    }

    // ─── REGISTRO ─────────────────────────────────────────────────────────────

    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        if (_users.EmailExists(model.Email))
        {
            ModelState.AddModelError(nameof(model.Email),
                "Ya existe una cuenta con este correo electrónico.");
            return View(model);
        }

        if (model.BirthDate > DateTime.Today.AddYears(-18))
        {
            ModelState.AddModelError(nameof(model.BirthDate),
                "Debes ser mayor de 18 años para registrarte.");
            return View(model);
        }

        var user = _users.Register(model);

        // Login automático tras el registro
        await SignInWithCookieAsync(user, persistent: false);

        TempData["Success"] = $"Bienvenido/a, {user.FullName}. Tu cuenta ha sido creada.";
        return RedirectToAction("Index", "Dashboard");
    }

    // ─── LOGIN ────────────────────────────────────────────────────────────────

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToAction("Index", "Dashboard");

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = _users.ValidateCredentials(model.Email, model.Password);
        if (user is null)
        {
            ModelState.AddModelError(string.Empty,
                "Credenciales incorrectas o cuenta bloqueada.");
            return View(model);
        }

        await SignInWithCookieAsync(user, model.RememberMe);

        TempData["Success"] = $"Sesión iniciada correctamente. Bienvenido/a, {user.FullName}.";

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);

        return RedirectToAction("Index", "Dashboard");
    }

    // ─── LOGOUT ───────────────────────────────────────────────────────────────

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        TempData["Info"] = "Has cerrado sesión correctamente.";
        return RedirectToAction(nameof(Login));
    }

    // ─── PERFIL ───────────────────────────────────────────────────────────────

    [Authorize]
    public IActionResult Profile()
    {
        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user   = _users.GetById(userId);
        if (user is null) return NotFound();

        var token  = _jwt.GenerateToken(user);
        var claims = _jwt.ValidateToken(token)?.Claims
            .Select(c => new ClaimDisplay(
                c.Type,
                c.Value,
                ClaimDescription(c.Type)))
            .ToList() ?? [];

        return View(new UserProfileViewModel
        {
            Id             = user.Id,
            FullName       = user.FullName,
            Email          = user.Email,
            Role           = user.Role,
            Department     = user.Department,
            Status         = user.Status,
            Age            = user.Age,
            HireDate       = user.HireDate,
            YearsOfService = user.YearsOfService,
            JwtToken       = token,
            DecodedClaims  = claims
        });
    }

    // ─── ACCESO DENEGADO ──────────────────────────────────────────────────────

    public IActionResult AccessDenied(string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private async Task SignInWithCookieAsync(ApplicationUser user, bool persistent)
    {
        // Creamos el ClaimsPrincipal con los mismos claims que llevaría el JWT,
        // de modo que las políticas de autorización funcionan igual con Cookie o JWT.
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email,          user.Email),
            new(ClaimTypes.Name,           user.FullName),
            new(ClaimTypes.Role,           user.Role.ToString()),
            new(Authorization.AppClaims.Department,  user.Department.ToString()),
            new(Authorization.AppClaims.Age,         user.Age.ToString()),
            new(Authorization.AppClaims.Status,      user.Status.ToString()),
            new(Authorization.AppClaims.HireDate,    user.HireDate.ToString("yyyy-MM-dd")),
            new(Authorization.AppClaims.EmployeeId,  user.Id.ToString()),
        };

        var identity  = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(identity);
        var props     = new AuthenticationProperties
        {
            IsPersistent = persistent,
            ExpiresUtc   = DateTimeOffset.UtcNow.AddHours(8)
        };

        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme, principal, props);
    }

    private static string ClaimDescription(string type) => type switch
    {
        "sub"              => "Identificador del sujeto (RFC 7519 §4.1.2)",
        "email"            => "Dirección de correo electrónico",
        "unique_name"      => "Nombre completo del usuario",
        "jti"              => "Identificador único del token (RFC 7519 §4.1.7)",
        "iat"              => "Fecha de emisión — Unix timestamp",
        "nbf"              => "No válido antes de — Unix timestamp",
        "exp"              => "Fecha de expiración — Unix timestamp",
        "iss"              => "Emisor del token",
        "aud"              => "Audiencia del token",
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"
                           => "Rol del usuario en la aplicación",
        "employee_id"      => "ID interno del empleado",
        "full_name"        => "Nombre completo (claim personalizado)",
        "department"       => "Departamento (claim personalizado)",
        "age"              => "Edad calculada del empleado (claim personalizado)",
        "employee_status"  => "Estado laboral del empleado (claim personalizado)",
        "hire_date"        => "Fecha de contratación (claim personalizado)",
        _                  => type
    };
}
