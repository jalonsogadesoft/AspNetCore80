using AuthDemo.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AuthDemo.Controllers;

/// <summary>
/// Dashboard accesible por cualquier usuario autenticado ([Authorize] sin roles).
/// Muestra un resumen de los claims del usuario actual para fines didácticos.
/// </summary>
[Authorize(Policy = Policies.ActiveEmployee)]
public class DashboardController : Controller
{
    public IActionResult Index()
    {
        var claims = User.Claims
            .Select(c => new { c.Type, c.Value })
            .ToList();

        ViewBag.Claims = claims;
        ViewBag.UserName  = User.FindFirstValue(ClaimTypes.Name);
        ViewBag.UserRole  = User.FindFirstValue(ClaimTypes.Role);
        ViewBag.UserDept  = User.FindFirstValue(AppClaims.Department);
        ViewBag.UserAge   = User.FindFirstValue(AppClaims.Age);
        ViewBag.Status    = User.FindFirstValue(AppClaims.Status);

        return View();
    }
}
