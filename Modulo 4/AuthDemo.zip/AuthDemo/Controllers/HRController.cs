using AuthDemo.Authorization;
using AuthDemo.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthDemo.Controllers;

/// <summary>
/// Módulo de Recursos Humanos. Demuestra la política "HROnly":
/// solo usuarios con claim department = "RecursosHumanos".
/// Combina además la política "ActiveEmployee".
/// </summary>
[Authorize(Policy = Policies.ActiveHR)]
public class HRController : Controller
{
    private readonly IUserService _users;

    public HRController(IUserService users) => _users = users;

    public IActionResult Index()
    {
        var employees = _users.GetAll()
            .Where(u => u.Status == Models.Enums.UserStatus.Activo)
            .OrderBy(u => u.FullName)
            .ToList();
        return View(employees);
    }
}
