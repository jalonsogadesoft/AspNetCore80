namespace AuthDemo.Models.Enums;

public enum Department
{
    Tecnologia,
    RecursosHumanos,
    Finanzas,
    Marketing,
    Operaciones
}
