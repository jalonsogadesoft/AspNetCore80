namespace AuthDemo.Models.Enums;

public enum UserStatus
{
    Activo,
    Inactivo,
    Bloqueado
}
