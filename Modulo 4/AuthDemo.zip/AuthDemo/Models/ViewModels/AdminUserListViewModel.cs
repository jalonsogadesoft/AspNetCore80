using AuthDemo.Models.ViewModels;

namespace AuthDemo.Models.ViewModels;

public class AdminUserListViewModel
{
    public IReadOnlyList<AdminUserRow> Users { get; set; } = [];
}

public class AdminUserRow
{
    public int    Id         { get; set; }
    public string FullName   { get; set; } = string.Empty;
    public string Email      { get; set; } = string.Empty;
    public string Role       { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string Status     { get; set; } = string.Empty;
    public int    Age        { get; set; }
    public double YearsOfService { get; set; }
}
