using AuthDemo.Models.Enums;

namespace AuthDemo.Models.ViewModels;

/// <summary>
/// ViewModel para mostrar la información del perfil del usuario
/// y su JWT con todos sus claims decodificados.
/// </summary>
public class UserProfileViewModel
{
    public int    Id           { get; set; }
    public string FullName     { get; set; } = string.Empty;
    public string Email        { get; set; } = string.Empty;
    public UserRole   Role       { get; set; }
    public Department Department { get; set; }
    public UserStatus Status     { get; set; }
    public int    Age           { get; set; }
    public DateTime HireDate    { get; set; }
    public double YearsOfService { get; set; }

    // JWT generado para este usuario
    public string JwtToken      { get; set; } = string.Empty;

    // Claims decodificados del JWT (para mostrar en la vista)
    public IReadOnlyList<ClaimDisplay> DecodedClaims { get; set; } = [];
}

public record ClaimDisplay(string Type, string Value, string Description);
