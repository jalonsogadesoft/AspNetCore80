using AuthDemo.Models.Enums;

namespace AuthDemo.Models;

/// <summary>
/// Usuario de la aplicación — modelo de dominio personalizado (sin ASP.NET Core Identity).
/// Contiene todos los atributos que se incluirán como claims en el JWT.
/// </summary>
public class ApplicationUser
{
    public int    Id           { get; set; }
    public string Email        { get; set; } = string.Empty;
    public string FullName     { get; set; } = string.Empty;

    // Credenciales — hash + salt almacenados separadamente (PBKDF2)
    public string PasswordHash { get; set; } = string.Empty;
    public string PasswordSalt { get; set; } = string.Empty;

    public UserRole   Role       { get; set; }
    public Department Department { get; set; }
    public UserStatus Status     { get; set; } = UserStatus.Activo;

    public DateTime BirthDate   { get; set; }
    public DateTime HireDate    { get; set; }
    public DateTime CreatedAt   { get; set; } = DateTime.UtcNow;

    // ── Claims calculados ───────────────────────────────────────────────────
    public int Age =>
        (int)((DateTime.Today - BirthDate).TotalDays / 365.25);

    public double YearsOfService =>
        Math.Round((DateTime.Today - HireDate).TotalDays / 365.25, 1);
}
