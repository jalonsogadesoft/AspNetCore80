using AuthDemo.Models;
using AuthDemo.Models.Enums;
using AuthDemo.Models.ViewModels;

namespace AuthDemo.Services;

public interface IUserService
{
    ApplicationUser? GetById(int id);
    ApplicationUser? GetByEmail(string email);
    IReadOnlyList<ApplicationUser> GetAll();
    bool EmailExists(string email);
    ApplicationUser Register(RegisterViewModel model);
    ApplicationUser? ValidateCredentials(string email, string password);
    bool UpdateStatus(int userId, UserStatus status);
    bool UpdateRole(int userId, UserRole role);
}

/// <summary>
/// Repositorio en memoria con datos semilla.
/// Inyectado como Singleton para que los registros persistan durante la sesión.
/// </summary>
public sealed class UserService : IUserService
{
    private readonly List<ApplicationUser> _users;
    private readonly IPasswordHasher _hasher;
    private int _nextId;

    public UserService(IPasswordHasher hasher)
    {
        _hasher = hasher;
        _users  = SeedUsers();
        _nextId = _users.Max(u => u.Id) + 1;
    }

    public ApplicationUser? GetById(int id)     => _users.FirstOrDefault(u => u.Id == id);
    public ApplicationUser? GetByEmail(string e) => _users.FirstOrDefault(
        u => u.Email.Equals(e, StringComparison.OrdinalIgnoreCase));
    public IReadOnlyList<ApplicationUser> GetAll() => _users.AsReadOnly();
    public bool EmailExists(string email) => GetByEmail(email) != null;

    public ApplicationUser Register(RegisterViewModel model)
    {
        var (hash, salt) = _hasher.Hash(model.Password);
        var user = new ApplicationUser
        {
            Id           = _nextId++,
            Email        = model.Email,
            FullName     = model.FullName,
            PasswordHash = hash,
            PasswordSalt = salt,
            Role         = UserRole.Empleado,     // rol por defecto al registrarse
            Department   = model.Department,
            Status       = UserStatus.Activo,
            BirthDate    = model.BirthDate,
            HireDate     = DateTime.Today,
            CreatedAt    = DateTime.UtcNow
        };
        _users.Add(user);
        return user;
    }

    public ApplicationUser? ValidateCredentials(string email, string password)
    {
        var user = GetByEmail(email);
        if (user is null) return null;
        if (user.Status == UserStatus.Bloqueado) return null;
        return _hasher.Verify(password, user.PasswordHash, user.PasswordSalt) ? user : null;
    }

    public bool UpdateStatus(int userId, UserStatus status)
    {
        var user = GetById(userId);
        if (user is null) return false;
        user.Status = status;
        return true;
    }

    public bool UpdateRole(int userId, UserRole role)
    {
        var user = GetById(userId);
        if (user is null) return false;
        user.Role = role;
        return true;
    }

    // ── Datos semilla ────────────────────────────────────────────────────────
    // Contraseña para todos: Demo1234!
    private List<ApplicationUser> SeedUsers()
    {
        ApplicationUser Seed(int id, string name, string email,
            UserRole role, Department dept, DateTime birth, DateTime hire,
            UserStatus status = UserStatus.Activo)
        {
            var (hash, salt) = _hasher.Hash("Demo1234!");
            return new ApplicationUser
            {
                Id = id, FullName = name, Email = email,
                PasswordHash = hash, PasswordSalt = salt,
                Role = role, Department = dept, Status = status,
                BirthDate = birth, HireDate = hire,
                CreatedAt = hire
            };
        }

        return new List<ApplicationUser>
        {
            Seed(1, "Admin Sistema",     "admin@demo.es",
                UserRole.Administrador, Department.Tecnologia,
                new DateTime(1985, 3, 10), new DateTime(2015, 1, 5)),

            Seed(2, "María Jefa RRHH",  "gerente.rrhh@demo.es",
                UserRole.Gerente, Department.RecursosHumanos,
                new DateTime(1982, 7, 22), new DateTime(2016, 4, 1)),

            Seed(3, "Pedro Finanzas",    "gerente.fin@demo.es",
                UserRole.Gerente, Department.Finanzas,
                new DateTime(1979, 11, 5), new DateTime(2014, 9, 15)),

            Seed(4, "Laura RRHH",        "rrhh@demo.es",
                UserRole.RRHH, Department.RecursosHumanos,
                new DateTime(1993, 5, 18), new DateTime(2020, 2, 10)),

            Seed(5, "Carlos Auditor",   "auditor@demo.es",
                UserRole.Auditor, Department.Finanzas,
                new DateTime(1988, 9, 3), new DateTime(2019, 6, 1)),

            Seed(6, "Ana Empleada",     "empleado@demo.es",
                UserRole.Empleado, Department.Marketing,
                new DateTime(1997, 12, 25), new DateTime(2022, 3, 7)),

            Seed(7, "Juan Bloqueado",   "bloqueado@demo.es",
                UserRole.Empleado, Department.Operaciones,
                new DateTime(1990, 4, 14), new DateTime(2021, 8, 1),
                UserStatus.Bloqueado),
        };
    }
}
