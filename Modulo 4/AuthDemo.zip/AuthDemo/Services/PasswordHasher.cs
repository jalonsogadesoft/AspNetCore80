using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Security.Cryptography;

namespace AuthDemo.Services;

/// <summary>
/// Hasher de contraseñas basado en PBKDF2-HMAC-SHA256.
/// Genera un salt aleatorio de 128 bits y deriva 256 bits en 350 000 iteraciones.
/// </summary>
public interface IPasswordHasher
{
    (string Hash, string Salt) Hash(string password);
    bool Verify(string password, string hash, string salt);
}

public sealed class PasswordHasher : IPasswordHasher
{
    private const int SaltSize    = 16;  // bytes
    private const int HashSize    = 32;  // bytes (256 bits)
    private const int Iterations  = 350_000;

    public (string Hash, string Salt) Hash(string password)
    {
        var saltBytes = RandomNumberGenerator.GetBytes(SaltSize);
        var hashBytes = Derive(password, saltBytes);
        return (Convert.ToBase64String(hashBytes), Convert.ToBase64String(saltBytes));
    }

    public bool Verify(string password, string hash, string salt)
    {
        var saltBytes = Convert.FromBase64String(salt);
        var expected  = Convert.FromBase64String(hash);
        var actual    = Derive(password, saltBytes);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }

    private static byte[] Derive(string password, byte[] salt) =>
        KeyDerivation.Pbkdf2(
            password:       password,
            salt:           salt,
            prf:            KeyDerivationPrf.HMACSHA256,
            iterationCount: Iterations,
            numBytesRequested: HashSize);
}
