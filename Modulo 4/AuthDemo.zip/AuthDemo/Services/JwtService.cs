using AuthDemo.Authorization;
using AuthDemo.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace AuthDemo.Services;

public interface IJwtService
{
    string GenerateToken(ApplicationUser user);
    ClaimsPrincipal? ValidateToken(string token);
}

/// <summary>
/// Servicio de emisión y validación de tokens JWT.
/// Incluye claims estándar (sub, email, name, jti, iat, exp)
/// y claims personalizados del dominio (department, age, status, hire_date, etc.).
/// </summary>
public sealed class JwtService : IJwtService
{
    private readonly JwtSettings _settings;
    private readonly SymmetricSecurityKey _key;

    public JwtService(IConfiguration config)
    {
        _settings = config.GetSection("Jwt").Get<JwtSettings>()
                    ?? throw new InvalidOperationException("Falta la sección 'Jwt' en appsettings.");
        _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_settings.SecretKey));
    }

    /// <summary>
    /// Genera un JWT firmado con HMAC-SHA256 que incluye:
    /// - Claims estándar: sub, email, unique_name, jti, iat, nbf, exp
    /// - Claims de rol: role (puede ser múltiple si se amplía)
    /// - Claims personalizados: employee_id, department, age, employee_status, hire_date, full_name
    /// </summary>
    public string GenerateToken(ApplicationUser user)
    {
        var now      = DateTime.UtcNow;
        var jti      = Guid.NewGuid().ToString("N");
        var expiry   = now.AddMinutes(_settings.ExpiryMinutes);

        var claims = new List<Claim>
        {
            // ── Claims estándar del RFC 7519 ──────────────────────────────
            new(JwtRegisteredClaimNames.Sub,         user.Id.ToString()),
            new(JwtRegisteredClaimNames.Email,       user.Email),
            new(JwtRegisteredClaimNames.UniqueName,  user.FullName),
            new(JwtRegisteredClaimNames.Jti,         jti),
            new(JwtRegisteredClaimNames.Iat,         DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString(),
                                                     ClaimValueTypes.Integer64),
            // ── Roles (ClaimTypes.Role para que IsInRole() funcione) ──────
            new(ClaimTypes.Role,                     user.Role.ToString()),

            // ── Claims personalizados del dominio ─────────────────────────
            new(AppClaims.EmployeeId,  user.Id.ToString()),
            new(AppClaims.FullName,    user.FullName),
            new(AppClaims.Department,  user.Department.ToString()),
            new(AppClaims.Age,         user.Age.ToString()),
            new(AppClaims.Status,      user.Status.ToString()),
            new(AppClaims.HireDate,    user.HireDate.ToString("yyyy-MM-dd")),
        };

        var creds     = new SigningCredentials(_key, SecurityAlgorithms.HmacSha256);
        var tokenDesc = new JwtSecurityToken(
            issuer:             _settings.Issuer,
            audience:           _settings.Audience,
            claims:             claims,
            notBefore:          now,
            expires:            expiry,
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(tokenDesc);
    }

    public ClaimsPrincipal? ValidateToken(string token)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();
            return handler.ValidateToken(token, BuildValidationParameters(), out _);
        }
        catch
        {
            return null;
        }
    }

    public TokenValidationParameters BuildValidationParameters() => new()
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey         = _key,
        ValidateIssuer           = true,
        ValidIssuer              = _settings.Issuer,
        ValidateAudience         = true,
        ValidAudience            = _settings.Audience,
        ValidateLifetime         = true,
        ClockSkew                = TimeSpan.Zero,
        RoleClaimType            = ClaimTypes.Role,
        NameClaimType            = JwtRegisteredClaimNames.UniqueName
    };
}

/// <summary>Configuración del JWT leída desde appsettings.json.</summary>
public sealed class JwtSettings
{
    public string SecretKey     { get; init; } = string.Empty;
    public string Issuer        { get; init; } = string.Empty;
    public string Audience      { get; init; } = string.Empty;
    public int    ExpiryMinutes { get; init; } = 60;
}
