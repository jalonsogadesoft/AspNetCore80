namespace AuthDemo.Authorization;

/// <summary>
/// Constantes con los nombres de las políticas de autorización registradas en Program.cs.
/// Centralizar aquí evita magic-strings dispersos por el código.
/// </summary>
public static class Policies
{
    /// <summary>Solo usuarios con rol Administrador.</summary>
    public const string RequireAdmin = "RequireAdmin";

    /// <summary>Solo usuarios del departamento de Recursos Humanos.</summary>
    public const string HROnly = "HROnly";

    /// <summary>Usuarios con edad verificada ≥ 18 años (claim personalizado).</summary>
    public const string MinimumAge18 = "MinimumAge18";

    /// <summary>
    /// Usuarios que pueden acceder a informes financieros:
    /// Administrador, o Gerente con departamento = Finanzas.
    /// </summary>
    public const string CanAccessFinanceReports = "CanAccessFinanceReports";

    /// <summary>
    /// El usuario debe estar en estado Activo (no bloqueado ni inactivo).
    /// Demuestra cómo combinar múltiples requisitos en una misma política.
    /// </summary>
    public const string ActiveEmployee = "ActiveEmployee";

    /// <summary>Roles de alta dirección: Administrador o Gerente.</summary>
    public const string SeniorStaff = "SeniorStaff";

    /// <summary>
    /// Política combinada: usuario activo + departamento RRHH.
    /// Demuestra la composición de múltiples IAuthorizationRequirement.
    /// </summary>
    public const string ActiveHR = "ActiveHR";
}

/// <summary>Nombres de los claims personalizados del JWT.</summary>
public static class AppClaims
{
    public const string EmployeeId  = "employee_id";
    public const string Department  = "department";
    public const string Status      = "employee_status";
    public const string HireDate    = "hire_date";
    public const string FullName    = "full_name";
    public const string Age         = "age";
}
