using AuthDemo.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Handlers;

/// <summary>
/// Handler para <see cref="ActiveEmployeeRequirement"/>.
/// El usuario solo supera este requisito si su claim "employee_status" es "Activo".
/// Un usuario Bloqueado o Inactivo falla explícitamente con context.Fail().
/// </summary>
public sealed class ActiveEmployeeHandler : AuthorizationHandler<ActiveEmployeeRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        ActiveEmployeeRequirement requirement)
    {
        var statusClaim = context.User.FindFirst(AppClaims.Status);

        if (statusClaim?.Value == "Activo")
        {
            context.Succeed(requirement);
        }
        else
        {
            // Fallo explícito: ningún otro handler puede revertirlo
            context.Fail(new AuthorizationFailureReason(this,
                "El usuario no está activo en el sistema."));
        }

        return Task.CompletedTask;
    }
}
