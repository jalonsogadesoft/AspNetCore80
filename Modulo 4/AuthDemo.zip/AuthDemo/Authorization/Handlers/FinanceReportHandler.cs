using AuthDemo.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Handlers;

/// <summary>
/// Handler para <see cref="FinanceReportRequirement"/>.
/// Lógica OR: aprueba si el usuario es Administrador,
/// o si es Gerente en el departamento de Finanzas.
/// Demuestra cómo combinar condiciones complejas en un solo handler.
/// </summary>
public sealed class FinanceReportHandler : AuthorizationHandler<FinanceReportRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        FinanceReportRequirement requirement)
    {
        var isAdmin   = context.User.IsInRole("Administrador");
        var isManager = context.User.IsInRole("Gerente");
        var dept      = context.User.FindFirst(AppClaims.Department)?.Value;
        var status    = context.User.FindFirst(AppClaims.Status)?.Value;

        // Solo puede acceder si el empleado está activo
        if (status != "Activo") return Task.CompletedTask;

        if (isAdmin || (isManager && dept == "Finanzas"))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}
