using AuthDemo.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Handlers;

/// <summary>
/// Handler para <see cref="MinimumAgeRequirement"/>.
/// Lee el claim "age" del ClaimsPrincipal y lo compara con el requisito.
/// </summary>
public sealed class MinimumAgeHandler : AuthorizationHandler<MinimumAgeRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        MinimumAgeRequirement requirement)
    {
        var ageClaim = context.User.FindFirst(AppClaims.Age);

        // Sin claim de edad → fallo silencioso (no llamamos a Fail para no bloquear otros handlers)
        if (ageClaim is null || !int.TryParse(ageClaim.Value, out var age))
            return Task.CompletedTask;

        if (age >= requirement.MinimumAge)
            context.Succeed(requirement);

        return Task.CompletedTask;
    }
}
