using AuthDemo.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Handlers;

/// <summary>
/// Handler para <see cref="DepartmentRequirement"/>.
/// Compara el claim "department" con el departamento requerido (case-insensitive).
/// </summary>
public sealed class DepartmentHandler : AuthorizationHandler<DepartmentRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        DepartmentRequirement requirement)
    {
        var deptClaim = context.User.FindFirst(AppClaims.Department);
        if (deptClaim is null) return Task.CompletedTask;

        if (string.Equals(deptClaim.Value, requirement.RequiredDepartment,
                          StringComparison.OrdinalIgnoreCase))
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}
