using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Requirements;

/// <summary>
/// Requisito: el claim "age" del usuario debe ser ≥ <see cref="MinimumAge"/>.
/// Demuestra un IAuthorizationRequirement con parámetro.
/// </summary>
public sealed class MinimumAgeRequirement : IAuthorizationRequirement
{
    public int MinimumAge { get; }

    public MinimumAgeRequirement(int minimumAge)
    {
        MinimumAge = minimumAge;
    }
}
