using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Requirements;

/// <summary>
/// Requisito: el claim "department" debe coincidir con <see cref="RequiredDepartment"/>.
/// </summary>
public sealed class DepartmentRequirement : IAuthorizationRequirement
{
    public string RequiredDepartment { get; }

    public DepartmentRequirement(string department)
    {
        RequiredDepartment = department;
    }
}
