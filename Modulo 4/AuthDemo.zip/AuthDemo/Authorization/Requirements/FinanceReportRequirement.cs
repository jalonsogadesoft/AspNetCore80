using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Requirements;

/// <summary>
/// Requisito compuesto: usuario Activo + departamento = Finanzas o Administrador.
/// Demuestra lógica OR dentro del mismo handler.
/// </summary>
public sealed class FinanceReportRequirement : IAuthorizationRequirement { }
