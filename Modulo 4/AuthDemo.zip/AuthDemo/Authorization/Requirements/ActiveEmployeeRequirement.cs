using Microsoft.AspNetCore.Authorization;

namespace AuthDemo.Authorization.Requirements;

/// <summary>
/// Requisito: el claim "employee_status" debe ser "Activo".
/// Demuestra un requisito sin parámetros (flag).
/// </summary>
public sealed class ActiveEmployeeRequirement : IAuthorizationRequirement { }
