using AuthDemo.Authorization;
using AuthDemo.Authorization.Handlers;
using AuthDemo.Authorization.Requirements;
using AuthDemo.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// ── MVC ─────────────────────────────────────────────────────────────────────
builder.Services.AddControllersWithViews();

// ── Servicios de dominio ─────────────────────────────────────────────────────
builder.Services.AddSingleton<IPasswordHasher, PasswordHasher>();
builder.Services.AddSingleton<IUserService,    UserService>();
builder.Services.AddSingleton<IJwtService,     JwtService>();

// ── Autenticación dual: Cookie (MVC) + JWT Bearer (API) ──────────────────────
var jwtKey = builder.Configuration["Jwt:SecretKey"]!;

builder.Services
    .AddAuthentication(options =>
    {
        // El esquema por defecto para MVC es Cookie
        options.DefaultScheme          = CookieAuthenticationDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    })
    .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
    {
        options.LoginPath          = "/Account/Login";
        options.LogoutPath         = "/Account/Logout";
        options.AccessDeniedPath   = "/Account/AccessDenied";
        options.ExpireTimeSpan     = TimeSpan.FromHours(8);
        options.SlidingExpiration  = true;
        options.Cookie.Name        = "AuthDemo.Session";
        options.Cookie.HttpOnly    = true;
        options.Cookie.SecurePolicy = Microsoft.AspNetCore.Http.CookieSecurePolicy.SameAsRequest;
    })
    .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
    {
        // El token Bearer se usa para /api/* (TokenController)
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey         = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            ValidateIssuer           = true,
            ValidIssuer              = builder.Configuration["Jwt:Issuer"],
            ValidateAudience         = true,
            ValidAudience            = builder.Configuration["Jwt:Audience"],
            ValidateLifetime         = true,
            ClockSkew                = TimeSpan.Zero,
            RoleClaimType            = System.Security.Claims.ClaimTypes.Role,
        };
    });

// ── Handlers de autorización ─────────────────────────────────────────────────
builder.Services.AddScoped<IAuthorizationHandler, MinimumAgeHandler>();
builder.Services.AddScoped<IAuthorizationHandler, DepartmentHandler>();
builder.Services.AddScoped<IAuthorizationHandler, ActiveEmployeeHandler>();
builder.Services.AddScoped<IAuthorizationHandler, FinanceReportHandler>();

// ── Políticas de autorización ────────────────────────────────────────────────
builder.Services.AddAuthorization(opts =>
{
    // 1. Solo Administrador (basada en rol)
    opts.AddPolicy(Policies.RequireAdmin, p =>
        p.RequireRole("Administrador"));

    // 2. Solo departamento Recursos Humanos (requisito personalizado con parámetro)
    opts.AddPolicy(Policies.HROnly, p =>
        p.AddRequirements(new DepartmentRequirement("RecursosHumanos")));

    // 3. Edad mínima de 18 años verificada por claim (requisito personalizado)
    opts.AddPolicy(Policies.MinimumAge18, p =>
        p.AddRequirements(new MinimumAgeRequirement(18)));

    // 4. Alta dirección: Administrador o Gerente (basada en múltiples roles)
    opts.AddPolicy(Policies.SeniorStaff, p =>
        p.RequireRole("Administrador", "Gerente"));

    // 5. Informes financieros: lógica OR compleja (handler personalizado)
    opts.AddPolicy(Policies.CanAccessFinanceReports, p =>
        p.AddRequirements(new FinanceReportRequirement()));

    // 6. Usuario activo en el sistema (handler con Fail explícito)
    opts.AddPolicy(Policies.ActiveEmployee, p =>
        p.AddRequirements(new ActiveEmployeeRequirement()));

    // 7. Política combinada: usuario activo + RRHH (múltiples requisitos en AND)
    opts.AddPolicy(Policies.ActiveHR, p =>
        p.AddRequirements(
            new ActiveEmployeeRequirement(),
            new DepartmentRequirement("RecursosHumanos")));
});

var app = builder.Build();

// ── Middleware pipeline ──────────────────────────────────────────────────────
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// Orden obligatorio: Authentication ANTES que Authorization
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Rutas de API (JWT Bearer)
app.MapControllers();

app.Run();
