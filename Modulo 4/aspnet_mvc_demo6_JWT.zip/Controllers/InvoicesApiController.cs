
using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo6_JWT.Application.Services;
using Microsoft.AspNetCore.Authorization;

namespace aspnet_mvc_demo6_JWT.Controllers;

[ApiController]
[Route("api/invoices")]
[Authorize]
public class InvoicesApiController:ControllerBase
{
    private readonly IInvoiceService _svc;
    public InvoicesApiController(IInvoiceService svc){_svc=svc;}

    [HttpGet]
    public IActionResult Get()=>Ok(_svc.GetAll());
}
