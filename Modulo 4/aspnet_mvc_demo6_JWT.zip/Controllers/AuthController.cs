
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace aspnet_mvc_demo6_JWT.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController:ControllerBase
{
    [HttpPost("login")]
    public IActionResult Login()
    {
        var key = Encoding.ASCII.GetBytes("super_secret_key_12345");
        var tokenDescriptor = new SecurityTokenDescriptor{
            Subject = new ClaimsIdentity(new[]{new Claim(ClaimTypes.Name,"demo")}),
            Expires=DateTime.UtcNow.AddHours(1),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),SecurityAlgorithms.HmacSha256Signature)
        };
        var handler = new JwtSecurityTokenHandler();
        var token = handler.CreateToken(tokenDescriptor);
        return Ok(handler.WriteToken(token));
    }
}
