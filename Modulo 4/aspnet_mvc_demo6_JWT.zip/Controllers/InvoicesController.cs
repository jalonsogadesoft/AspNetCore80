
using Microsoft.AspNetCore.Mvc;
using aspnet_mvc_demo6_JWT.Application.Services;
using aspnet_mvc_demo6_JWT.Domain;

namespace aspnet_mvc_demo6_JWT.Controllers;

public class InvoicesController:Controller
{
    private readonly IInvoiceService _svc;
    public InvoicesController(IInvoiceService svc){_svc=svc;}

    public IActionResult Index()=>View(_svc.GetAll());

    public IActionResult Create()=>View();

    [HttpPost]
    public IActionResult Create(Invoice i){_svc.Create(i);return RedirectToAction("Index");}
}
