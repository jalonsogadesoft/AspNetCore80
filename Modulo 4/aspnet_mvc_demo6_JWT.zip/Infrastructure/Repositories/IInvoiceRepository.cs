
using aspnet_mvc_demo6_JWT.Domain;
namespace aspnet_mvc_demo6_JWT.Infrastructure.Repositories;
public interface IInvoiceRepository
{
    IQueryable<Invoice> GetAll();
    void Add(Invoice i);
    void Save();
}
