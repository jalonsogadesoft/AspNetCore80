
using aspnet_mvc_demo6_JWT.Domain;
namespace aspnet_mvc_demo6_JWT.Infrastructure.Repositories;
public class InvoiceRepository:IInvoiceRepository
{
    private readonly AppDbContext _ctx;
    public InvoiceRepository(AppDbContext ctx){_ctx=ctx;}
    public IQueryable<Invoice> GetAll()=>_ctx.Invoices;
    public void Add(Invoice i)=>_ctx.Invoices.Add(i);
    public void Save()=>_ctx.SaveChanges();
}
