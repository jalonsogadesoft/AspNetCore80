
using Microsoft.EntityFrameworkCore;
using aspnet_mvc_demo6_JWT.Domain;

namespace aspnet_mvc_demo6_JWT.Infrastructure;
public class AppDbContext:DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> opt):base(opt){}
    public DbSet<Invoice> Invoices => Set<Invoice>();
}
