
using aspnet_mvc_demo6_JWT.Domain;
namespace aspnet_mvc_demo6_JWT.Application.Services;
public interface IInvoiceService
{
    IEnumerable<Invoice> GetAll();
    void Create(Invoice i);
}
