
using aspnet_mvc_demo6_JWT.Domain;
using aspnet_mvc_demo6_JWT.Infrastructure.Repositories;
namespace aspnet_mvc_demo6_JWT.Application.Services;
public class InvoiceService:IInvoiceService
{
    private readonly IInvoiceRepository _repo;
    public InvoiceService(IInvoiceRepository repo){_repo=repo;}
    public IEnumerable<Invoice> GetAll()=>_repo.GetAll().ToList();
    public void Create(Invoice i){_repo.Add(i);_repo.Save();}
}
